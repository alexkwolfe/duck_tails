#include "git_functions.hpp"
#include "git_filesystem.hpp"
#include "git_utils.hpp"
#include "duckdb/common/exception.hpp"
#include "duckdb/common/types/value.hpp"
#include "duckdb/main/extension_util.hpp"
#include "duckdb/function/table_function.hpp"
#include "duckdb/parser/parsed_data/create_table_function_info.hpp"

namespace duckdb {

//===--------------------------------------------------------------------===//
// UTF-8 Validation Helper
//===--------------------------------------------------------------------===//

// Simple UTF-8 validation to prevent verification crashes
static bool IsValidUTF8(const char* data, size_t length) {
    const unsigned char* bytes = reinterpret_cast<const unsigned char*>(data);
    for (size_t i = 0; i < length; ) {
        unsigned char byte = bytes[i];
        
        // ASCII (0-127)
        if (byte <= 0x7F) {
            i++;
            continue;
        }
        
        // Multi-byte sequence
        int num_bytes = 0;
        if ((byte & 0xE0) == 0xC0) {
            num_bytes = 2;
        } else if ((byte & 0xF0) == 0xE0) {
            num_bytes = 3;
        } else if ((byte & 0xF8) == 0xF0) {
            num_bytes = 4;
        } else {
            return false; // Invalid start byte
        }
        
        // Check if we have enough bytes
        if (i + num_bytes > length) {
            return false;
        }
        
        // Check continuation bytes
        for (int j = 1; j < num_bytes; j++) {
            if ((bytes[i + j] & 0xC0) != 0x80) {
                return false;
            }
        }
        
        i += num_bytes;
    }
    return true;
}

//===--------------------------------------------------------------------===//
// Unified Parameter Parsing Helper for New Signature Design
//===--------------------------------------------------------------------===//

struct UnifiedGitParams {
    string repo_path_or_uri;
    string resolved_repo_path;
    string resolved_file_path;  // For git_read
    string ref;                 // Optional ref parameter
    bool has_embedded_ref;      // True if ref came from git:// URI
    
    UnifiedGitParams() : repo_path_or_uri("."), resolved_repo_path("."), resolved_file_path(""), ref("HEAD"), has_embedded_ref(false) {}
};

// Parse parameters using new unified signature: func(repo_path_or_uri, [optional_ref], [other_params...])
static UnifiedGitParams ParseUnifiedGitParams(TableFunctionBindInput &input, int ref_param_index = 1) {
    UnifiedGitParams params;
    
    // First parameter is always repo_path_or_uri
    if (!input.inputs.empty()) {
        auto &first_arg = input.inputs[0];
        if (first_arg.type().id() == LogicalTypeId::VARCHAR) {
            params.repo_path_or_uri = first_arg.GetValue<string>();
        }
    }
    
    // Check if it's a git:// URI with embedded ref
    if (StringUtil::StartsWith(params.repo_path_or_uri, "git://")) {
        try {
            auto git_path = GitPath::Parse(params.repo_path_or_uri);
            params.resolved_repo_path = git_path.repository_path;
            params.resolved_file_path = git_path.file_path;
            params.ref = git_path.revision.empty() ? "HEAD" : git_path.revision;
            params.has_embedded_ref = !git_path.revision.empty();
        } catch (const std::exception &e) {
            throw BinderException("Failed to parse git:// URI '%s': %s", params.repo_path_or_uri, e.what());
        }
    } else {
        // Filesystem path - use repository discovery
        try {
            auto git_path = GitPath::Parse("git://" + params.repo_path_or_uri + "@HEAD");
            params.resolved_repo_path = git_path.repository_path;
            params.resolved_file_path = git_path.file_path;
            params.ref = "HEAD";  // Default for filesystem paths
            params.has_embedded_ref = false;
        } catch (const std::exception &e) {
            throw BinderException("Failed to resolve repository path '%s': %s", params.repo_path_or_uri, e.what());
        }
    }
    
    // Check for optional ref parameter (if not embedded in URI)
    if (input.inputs.size() > ref_param_index && !input.inputs[ref_param_index].IsNull()) {
        string explicit_ref = input.inputs[ref_param_index].GetValue<string>();
        
        if (params.has_embedded_ref && !explicit_ref.empty()) {
            throw BinderException("Conflicting ref specifications: git:// URI contains '@%s' but function parameter specifies '%s'", 
                                params.ref, explicit_ref);
        }
        
        if (!params.has_embedded_ref && !explicit_ref.empty()) {
            params.ref = explicit_ref;
        }
    }
    
    return params;
}

// Parse parameters for LATERAL functions where repo_path comes from runtime DataChunk
// This function only processes static bind-time parameters (like ref, options)
static UnifiedGitParams ParseLateralGitParams(TableFunctionBindInput &input, int ref_param_index = 1) {
    UnifiedGitParams params;
    
    // For LATERAL functions, repo_path comes from runtime DataChunk, not bind time
    // So we only process the optional static parameters here
    
    // Check for optional ref parameter
    if (input.inputs.size() > ref_param_index && !input.inputs[ref_param_index].IsNull()) {
        string explicit_ref = input.inputs[ref_param_index].GetValue<string>();
        if (!explicit_ref.empty()) {
            params.ref = explicit_ref;
        }
    }
    
    // Note: repo_path_or_uri, resolved_repo_path, resolved_file_path will be set at runtime
    return params;
}

//===--------------------------------------------------------------------===//
// Helper Functions for Schema Definition and Output
//===--------------------------------------------------------------------===//

// Schema definition for git_tree (ALWAYS includes repo_path as first column)
static void DefineGitTreeSchema(vector<LogicalType> &return_types, vector<string> &names) {
    return_types = {
        LogicalType::VARCHAR,    // git_uri (complete git:// URI)
        LogicalType::VARCHAR,    // repo_path (repository filesystem path)
        LogicalType::VARCHAR,    // commit_hash (git commit hash)
        LogicalType::VARCHAR,    // tree_hash (git tree hash containing the file)
        LogicalType::VARCHAR,    // file_path (file path within repository)
        LogicalType::VARCHAR,    // file_ext (file extension)
        LogicalType::VARCHAR,    // ref (git reference)
        LogicalType::VARCHAR,    // blob_hash (git blob hash of file content)
        LogicalType::TIMESTAMP,  // commit_date (commit timestamp)
        LogicalType::INTEGER,    // mode (file mode)
        LogicalType::BIGINT,     // size_bytes (file size in bytes)
        LogicalType::VARCHAR,    // kind (object kind: blob, tree, etc.)
        LogicalType::BOOLEAN,    // is_text (whether content is text)
        LogicalType::VARCHAR     // encoding (text encoding: utf8, binary)
    };
    names = {"git_uri", "repo_path", "commit_hash", "tree_hash", "file_path", "file_ext", 
             "ref", "blob_hash", "commit_date", "mode", "size_bytes", "kind", "is_text", "encoding"};
}

// Schema definition for git_parents (ALWAYS includes repo_path as first column)
static void DefineGitParentsSchema(vector<LogicalType> &return_types, vector<string> &names) {
    return_types = {
        LogicalType::VARCHAR,    // repo_path (ALWAYS first)
        LogicalType::VARCHAR,    // commit_hash
        LogicalType::VARCHAR,    // parent_hash
        LogicalType::INTEGER     // parent_index
    };
    names = {"repo_path", "commit_hash", "parent_hash", "parent_index"};
}

// Output helper for git_tree rows (repo_path is REQUIRED) - SAFE VERSION
static void OutputGitTreeRow(DataChunk &output, idx_t row_idx, 
                             const GitTreeRow &row, const string &repo_path) {
    // Use safe SetValue pattern instead of direct FlatVector access (Our Fix #1)
    output.SetValue(0, row_idx, Value(row.git_uri));
    output.SetValue(1, row_idx, Value(repo_path));
    output.SetValue(2, row_idx, Value(row.commit_hash));
    output.SetValue(3, row_idx, Value(row.tree_hash));
    output.SetValue(4, row_idx, Value(row.file_path));
    output.SetValue(5, row_idx, Value(row.file_ext));
    output.SetValue(6, row_idx, Value(row.ref));
    output.SetValue(7, row_idx, Value(row.blob_hash));
    output.SetValue(8, row_idx, Value::TIMESTAMP(row.commit_date));
    output.SetValue(9, row_idx, Value::INTEGER(row.mode));
    output.SetValue(10, row_idx, Value::BIGINT(row.size_bytes));
    output.SetValue(11, row_idx, Value(row.kind));
    output.SetValue(12, row_idx, Value::BOOLEAN(row.is_text));
    output.SetValue(13, row_idx, Value(row.encoding));
}

// Output helper for git_parents rows (repo_path is REQUIRED)
static void OutputGitParentsRow(DataChunk &output, idx_t row_idx,
                                const GitParentsRow &row, const string &repo_path) {
    idx_t col = 0;
    output.SetValue(col++, row_idx, Value(repo_path));              // repo_path
    output.SetValue(col++, row_idx, Value(row.commit_hash));        // commit_hash
    output.SetValue(col++, row_idx, Value(row.parent_hash));        // parent_hash
    output.SetValue(col++, row_idx, Value::INTEGER(row.parent_index)); // parent_index
}

//===--------------------------------------------------------------------===//
// Git Log Function
//===--------------------------------------------------------------------===//

GitLogFunctionData::GitLogFunctionData(const string &repo_path, const string &resolved_repo_path) 
    : repo_path(repo_path), resolved_repo_path(resolved_repo_path), repo(nullptr), walker(nullptr), initialized(false) {
}

GitLogFunctionData::~GitLogFunctionData() {
    if (walker) {
        git_revwalk_free(walker);
    }
    if (repo) {
        git_repository_free(repo);
    }
}

unique_ptr<FunctionData> GitLogBind(ClientContext &context, TableFunctionBindInput &input,
                                   vector<LogicalType> &return_types, vector<string> &names) {
    
    // Use unified parameter parsing to support both git:// URIs and filesystem paths
    auto params = ParseUnifiedGitParams(input, 1);  // ref parameter at index 1 (optional)
    
    // Define return schema with repo_path as first column
    return_types = {
        LogicalType::VARCHAR,    // repo_path
        LogicalType::VARCHAR,    // commit_hash
        LogicalType::VARCHAR,    // author_name  
        LogicalType::VARCHAR,    // author_email
        LogicalType::VARCHAR,    // committer_name
        LogicalType::VARCHAR,    // committer_email
        LogicalType::TIMESTAMP,  // author_date
        LogicalType::TIMESTAMP,  // commit_date
        LogicalType::VARCHAR,    // message
        LogicalType::INTEGER,    // parent_count
        LogicalType::VARCHAR     // tree_hash
    };
    
    names = {
        "repo_path", "commit_hash", "author_name", "author_email", "committer_name", "committer_email",
        "author_date", "commit_date", "message", "parent_count", "tree_hash"
    };
    
    return make_uniq<GitLogFunctionData>(params.repo_path_or_uri, params.resolved_repo_path);
}

unique_ptr<GlobalTableFunctionState> GitLogInitGlobal(ClientContext &context, TableFunctionInitInput &input) {
    return make_uniq<GlobalTableFunctionState>();
}

unique_ptr<LocalTableFunctionState> GitLogLocalInit(ExecutionContext &context, TableFunctionInitInput &input, GlobalTableFunctionState *global_state) {
    return make_uniq<GitLogLocalState>();
}

unique_ptr<LocalTableFunctionState> GitBranchesLocalInit(ExecutionContext &context, TableFunctionInitInput &input, GlobalTableFunctionState *global_state) {
    return make_uniq<GitBranchesLocalState>();
}

unique_ptr<LocalTableFunctionState> GitTagsLocalInit(ExecutionContext &context, TableFunctionInitInput &input, GlobalTableFunctionState *global_state) {
    return make_uniq<GitTagsLocalState>();
}

void GitLogFunction(ClientContext &context, TableFunctionInput &data_p, DataChunk &output) {
    auto &data = (GitLogFunctionData &)*data_p.bind_data;
    
    if (!data.initialized) {
        // Open repository using resolved path
        int error = git_repository_open(&data.repo, data.resolved_repo_path.c_str());
        if (error != 0) {
            const git_error *e = git_error_last();
            throw IOException("Failed to open git repository '%s': %s", 
                            data.repo_path, e ? e->message : "Unknown error");
        }
        
        // Create revwalk
        error = git_revwalk_new(&data.walker, data.repo);
        if (error != 0) {
            const git_error *e = git_error_last();
            throw IOException("Failed to create revwalk: %s", e ? e->message : "Unknown error");
        }
        
        // Push HEAD
        error = git_revwalk_push_head(data.walker);
        if (error != 0) {
            const git_error *e = git_error_last();
            throw IOException("Failed to push HEAD: %s", e ? e->message : "Unknown error");
        }
        
        data.initialized = true;
    }
    
    idx_t count = 0;
    git_oid oid;
    
    while (count < STANDARD_VECTOR_SIZE && git_revwalk_next(&oid, data.walker) == 0) {
        git_commit *commit = nullptr;
        int error = git_commit_lookup(&commit, data.repo, &oid);
        if (error != 0) {
            continue; // Skip invalid commits
        }
        
        // Set repo_path as first column
        output.SetValue(0, count, Value(data.repo_path));
        
        // Get commit hash
        char hash_str[GIT_OID_HEXSZ + 1];
        git_oid_tostr(hash_str, sizeof(hash_str), &oid);
        output.SetValue(1, count, Value(hash_str));
        
        // Get author info
        const git_signature *author = git_commit_author(commit);
        output.SetValue(2, count, Value(author->name ? author->name : ""));
        output.SetValue(3, count, Value(author->email ? author->email : ""));
        
        // Get committer info
        const git_signature *committer = git_commit_committer(commit);
        output.SetValue(4, count, Value(committer->name ? committer->name : ""));
        output.SetValue(5, count, Value(committer->email ? committer->email : ""));
        
        // Get timestamps
        timestamp_t author_ts = Timestamp::FromEpochSeconds(author->when.time);
        timestamp_t commit_ts = Timestamp::FromEpochSeconds(committer->when.time);
        output.SetValue(6, count, Value::TIMESTAMP(author_ts));
        output.SetValue(7, count, Value::TIMESTAMP(commit_ts));
        
        // Get commit message
        const char *message = git_commit_message(commit);
        output.SetValue(8, count, Value(message ? message : ""));
        
        // Get parent count
        unsigned int parent_count = git_commit_parentcount(commit);
        output.SetValue(9, count, Value::INTEGER(parent_count));
        
        // Get tree hash
        const git_oid *tree_oid = git_commit_tree_id(commit);
        char tree_hash[GIT_OID_HEXSZ + 1];
        git_oid_tostr(tree_hash, sizeof(tree_hash), tree_oid);
        output.SetValue(10, count, Value(tree_hash));
        
        git_commit_free(commit);
        count++;
    }
    
    output.SetCardinality(count);
}

//===--------------------------------------------------------------------===//
// Git Branches Function
//===--------------------------------------------------------------------===//

GitBranchesFunctionData::GitBranchesFunctionData(const string &repo_path, const string &resolved_repo_path)
    : repo_path(repo_path), resolved_repo_path(resolved_repo_path), repo(nullptr), iterator(nullptr), initialized(false) {
}

GitBranchesFunctionData::~GitBranchesFunctionData() {
    if (iterator) {
        git_branch_iterator_free(iterator);
    }
    if (repo) {
        git_repository_free(repo);
    }
}

unique_ptr<FunctionData> GitBranchesBind(ClientContext &context, TableFunctionBindInput &input,
                                        vector<LogicalType> &return_types, vector<string> &names) {
    
    // Use unified parameter parsing to support both git:// URIs and filesystem paths
    auto params = ParseUnifiedGitParams(input, 1);  // ref parameter at index 1 (optional)
    
    return_types = {
        LogicalType::VARCHAR,  // repo_path
        LogicalType::VARCHAR,  // branch_name
        LogicalType::VARCHAR,  // commit_hash
        LogicalType::BOOLEAN,  // is_current
        LogicalType::BOOLEAN   // is_remote
    };
    
    names = {"repo_path", "branch_name", "commit_hash", "is_current", "is_remote"};
    
    return make_uniq<GitBranchesFunctionData>(params.repo_path_or_uri, params.resolved_repo_path);
}

unique_ptr<GlobalTableFunctionState> GitBranchesInitGlobal(ClientContext &context, TableFunctionInitInput &input) {
    return make_uniq<GlobalTableFunctionState>();
}

void GitBranchesFunction(ClientContext &context, TableFunctionInput &data_p, DataChunk &output) {
    auto &data = (GitBranchesFunctionData &)*data_p.bind_data;
    
    if (!data.initialized) {
        int error = git_repository_open(&data.repo, data.resolved_repo_path.c_str());
        if (error != 0) {
            const git_error *e = git_error_last();
            throw IOException("Failed to open git repository '%s': %s", 
                            data.resolved_repo_path, e ? e->message : "Unknown error");
        }
        
        error = git_branch_iterator_new(&data.iterator, data.repo, GIT_BRANCH_ALL);
        if (error != 0) {
            const git_error *e = git_error_last();
            throw IOException("Failed to create branch iterator: %s", e ? e->message : "Unknown error");
        }
        
        data.initialized = true;
    }
    
    idx_t count = 0;
    git_reference *ref = nullptr;
    git_branch_t branch_type;
    
    while (count < STANDARD_VECTOR_SIZE && git_branch_next(&ref, &branch_type, data.iterator) == 0) {
        // Set repo_path as first column
        output.SetValue(0, count, Value(data.repo_path));
        
        // Get branch name
        const char *branch_name = nullptr;
        git_branch_name(&branch_name, ref);
        output.SetValue(1, count, Value(branch_name ? branch_name : ""));
        
        // Get commit hash
        const git_oid *oid = git_reference_target(ref);
        if (oid) {
            char hash_str[GIT_OID_HEXSZ + 1];
            git_oid_tostr(hash_str, sizeof(hash_str), oid);
            output.SetValue(2, count, Value(hash_str));
        } else {
            output.SetValue(2, count, Value(""));
        }
        
        // Check if current branch
        bool is_current = git_branch_is_head(ref) == 1;
        output.SetValue(3, count, Value::BOOLEAN(is_current));
        
        // Check if remote branch
        bool is_remote = (branch_type == GIT_BRANCH_REMOTE);
        output.SetValue(4, count, Value::BOOLEAN(is_remote));
        
        git_reference_free(ref);
        count++;
    }
    
    output.SetCardinality(count);
}

//===--------------------------------------------------------------------===//
// Git Tags Function
//===--------------------------------------------------------------------===//

GitTagsFunctionData::GitTagsFunctionData(const string &repo_path, const string &resolved_repo_path)
    : repo_path(repo_path), resolved_repo_path(resolved_repo_path), repo(nullptr), current_index(0), initialized(false) {
}

GitTagsFunctionData::~GitTagsFunctionData() {
    if (repo) {
        git_repository_free(repo);
    }
}

static int tag_foreach_cb(const char *name, git_oid *oid, void *payload) {
    auto *tag_names = static_cast<vector<string>*>(payload);
    if (StringUtil::StartsWith(name, "refs/tags/")) {
        tag_names->push_back(name + 10); // Remove "refs/tags/" prefix
    }
    return 0;
}

unique_ptr<FunctionData> GitTagsBind(ClientContext &context, TableFunctionBindInput &input,
                                    vector<LogicalType> &return_types, vector<string> &names) {
    
    // Use unified parameter parsing to support both git:// URIs and filesystem paths
    auto params = ParseUnifiedGitParams(input, 1);  // ref parameter at index 1 (optional)
    
    return_types = {
        LogicalType::VARCHAR,    // repo_path
        LogicalType::VARCHAR,    // tag_name
        LogicalType::VARCHAR,    // commit_hash
        LogicalType::VARCHAR,    // tagger_name
        LogicalType::TIMESTAMP,  // tagger_date
        LogicalType::VARCHAR,    // message
        LogicalType::BOOLEAN     // is_annotated
    };
    
    names = {"repo_path", "tag_name", "commit_hash", "tagger_name", "tagger_date", "message", "is_annotated"};
    
    return make_uniq<GitTagsFunctionData>(params.repo_path_or_uri, params.resolved_repo_path);
}

unique_ptr<GlobalTableFunctionState> GitTagsInitGlobal(ClientContext &context, TableFunctionInitInput &input) {
    return make_uniq<GlobalTableFunctionState>();
}

void GitTagsFunction(ClientContext &context, TableFunctionInput &data_p, DataChunk &output) {
    auto &data = (GitTagsFunctionData &)*data_p.bind_data;
    
    if (!data.initialized) {
        int error = git_repository_open(&data.repo, data.resolved_repo_path.c_str());
        if (error != 0) {
            const git_error *e = git_error_last();
            throw IOException("Failed to open git repository '%s': %s", 
                            data.resolved_repo_path, e ? e->message : "Unknown error");
        }
        
        // Get all tags
        error = git_tag_foreach(data.repo, tag_foreach_cb, &data.tag_names);
        if (error != 0) {
            const git_error *e = git_error_last();
            throw IOException("Failed to list tags: %s", e ? e->message : "Unknown error");
        }
        
        data.initialized = true;
    }
    
    idx_t count = 0;
    
    while (count < STANDARD_VECTOR_SIZE && data.current_index < data.tag_names.size()) {
        const string &tag_name = data.tag_names[data.current_index];
        
        // Look up tag reference
        git_reference *tag_ref = nullptr;
        string full_name = "refs/tags/" + tag_name;
        int error = git_reference_lookup(&tag_ref, data.repo, full_name.c_str());
        if (error == 0) {
            // Set repo_path as first column
            output.SetValue(0, count, Value(data.repo_path));
            output.SetValue(1, count, Value(tag_name));
            
            const git_oid *oid = git_reference_target(tag_ref);
            if (oid) {
                char hash_str[GIT_OID_HEXSZ + 1];
                git_oid_tostr(hash_str, sizeof(hash_str), oid);
                output.SetValue(2, count, Value(hash_str));
                
                // Try to get tag object for annotation info
                git_tag *tag_obj = nullptr;
                bool is_annotated = false;
                if (git_tag_lookup(&tag_obj, data.repo, oid) == 0) {
                    is_annotated = true;
                    
                    const git_signature *tagger = git_tag_tagger(tag_obj);
                    if (tagger) {
                        output.SetValue(3, count, Value(tagger->name ? tagger->name : ""));
                        timestamp_t tag_ts = Timestamp::FromEpochSeconds(tagger->when.time);
                        output.SetValue(4, count, Value::TIMESTAMP(tag_ts));
                    } else {
                        output.SetValue(3, count, Value(""));
                        output.SetValue(4, count, Value());
                    }
                    
                    const char *message = git_tag_message(tag_obj);
                    output.SetValue(5, count, Value(message ? message : ""));
                    
                    git_tag_free(tag_obj);
                } else {
                    // Lightweight tag
                    output.SetValue(3, count, Value(""));
                    output.SetValue(4, count, Value());
                    output.SetValue(5, count, Value(""));
                }
                
                output.SetValue(6, count, Value::BOOLEAN(is_annotated));
            }
            
            git_reference_free(tag_ref);
            count++;
        }
        
        data.current_index++;
    }
    
    output.SetCardinality(count);
}

//===--------------------------------------------------------------------===//
// Git Tree Function
//===--------------------------------------------------------------------===//

GitTreeFunctionData::GitTreeFunctionData(const string &ref, const string &repo_path) 
    : mode(GitTreeMode::SINGLE), ref(ref), repo_path(repo_path), current_index(0), is_dynamic(false) {
}


GitTreeFunctionData::GitTreeFunctionData(const string &range, const string &repo_path, bool is_range)
    : mode(GitTreeMode::RANGE), commit_range(range), repo_path(repo_path), current_index(0), is_dynamic(false) {
}

static string oid_to_hex(const git_oid *oid) {
    char hex[GIT_OID_HEXSZ + 1];
    git_oid_tostr(hex, sizeof(hex), oid);
    return string(hex);
}

static bool IsCommitRange(const string &param) {
    // Check for git range syntax
    return param.find("..") != string::npos || 
           param == "--all" || 
           param.find("~") != string::npos ||
           param.find("^") != string::npos;
}


// Core function to construct git:// URI from components
// This is the single source of truth for URI construction logic
static string ConstructGitUri(const string &repo_path, const string &file_path, const string &revision) {
    // Start with git:// prefix and repo path
    string uri = "git://" + repo_path;
    
    // Add file path if present
    if (!file_path.empty()) {
        // Add separator if repo_path doesn't end with / and file_path doesn't start with /
        if (!repo_path.empty() && repo_path.back() != '/' && file_path[0] != '/') {
            uri += "/";
        }
        uri += file_path;
    }
    
    // Add revision
    uri += "@" + revision;
    return uri;
}

// Helper function to construct git:// URI for a file (wraps ConstructGitUri)
static string BuildGitFileUri(const string &repo_path, const string &file_path, const string &commit_hash) {
    return ConstructGitUri(repo_path, file_path, commit_hash);
}

// Helper function to extract file extension from a file path
static string ExtractFileExtension(const string &file_path) {
    if (file_path.empty()) {
        return "";
    }
    
    size_t dot_pos = file_path.find_last_of('.');
    size_t slash_pos = file_path.find_last_of('/');
    
    // Make sure the dot is after the last slash (to handle directories like "dir.name/file")
    if (dot_pos != string::npos && (slash_pos == string::npos || dot_pos > slash_pos)) {
        return file_path.substr(dot_pos);  // Include the dot
    }
    
    return "";  // No extension found
}


static void traverse_tree(git_repository *repo, git_tree *tree, const string &base, vector<GitTreeRow> &out, 
                          const string &commit_hash, timestamp_t commit_date, const string &repo_path) {
    const size_t count = git_tree_entrycount(tree);
    for (size_t i = 0; i < count; ++i) {
        const git_tree_entry *entry = git_tree_entry_byindex(tree, i);
        const char *name = git_tree_entry_name(entry);
        git_object_t type = git_tree_entry_type(entry);
        const git_oid *oid = git_tree_entry_id(entry);
        int32_t mode = git_tree_entry_filemode(entry);

        string path = base.empty() ? string(name) : (base + "/" + name);

        if (type == GIT_OBJECT_BLOB) {
            git_blob *blob = nullptr;
            int64_t size_bytes = 0;
            // Determine object type based on filemode (consistent with git_read)
            string kind;
            switch (mode) {
                case GIT_FILEMODE_BLOB:
                case GIT_FILEMODE_BLOB_EXECUTABLE:
                    kind = "file";
                    break;
                case GIT_FILEMODE_LINK:
                    kind = "symlink";
                    break;
                case GIT_FILEMODE_TREE:
                    kind = "tree";
                    break;
                case GIT_FILEMODE_COMMIT:
                    kind = "submodule";
                    break;
                default:
                    kind = "unknown";
                    break;
            }
            bool is_text = false;
            string encoding = "unknown";
            
            if (git_blob_lookup(&blob, repo, oid) == 0) {
                size_bytes = static_cast<int64_t>(git_blob_rawsize(blob));
                is_text = !git_blob_is_binary(blob);  // Use libgit2's efficient binary detection
                encoding = is_text ? "utf8" : "binary";
                git_blob_free(blob);
            }
            
            // Build git:// URI and extract components - ensure proper string copies
            string git_uri = BuildGitFileUri(repo_path, path, commit_hash);
            string file_ext = ExtractFileExtension(path);
            
            // Extract URI components (file_path and ref should match path and commit_hash)
            string extracted_file_path = string(path);  // Explicit copy
            string ref = string(commit_hash);  // Explicit copy
            
            // Compute tree hash - get the tree containing this blob
            string tree_hash = oid_to_hex(git_tree_id(tree));
            string blob_hash = oid_to_hex(oid);  // Store in variable to avoid temp object
            
            // Create the row with explicit string copies to ensure memory safety
            GitTreeRow row;
            row.git_uri = std::move(git_uri);
            row.repo_path = string(repo_path);
            row.commit_hash = string(commit_hash);
            row.tree_hash = std::move(tree_hash);
            row.file_path = std::move(extracted_file_path);
            row.file_ext = std::move(file_ext);
            row.ref = std::move(ref);
            row.blob_hash = std::move(blob_hash);
            row.commit_date = commit_date;
            row.mode = mode;
            row.size_bytes = size_bytes;
            row.kind = string(kind);  // Explicit copy
            row.is_text = is_text;
            row.encoding = string(encoding);  // Explicit copy
            
            out.push_back(std::move(row));
        } else if (type == GIT_OBJECT_TREE) {
            git_tree *subtree = nullptr;
            if (git_tree_lookup(&subtree, repo, oid) == 0) {
                traverse_tree(repo, subtree, path, out, commit_hash, commit_date, repo_path);
                git_tree_free(subtree);
            }
        }
    }
}

unique_ptr<FunctionData> GitTreeBind(ClientContext &context, TableFunctionBindInput &input,
                                    vector<LogicalType> &return_types, vector<string> &names) {
    
    // Use unified parameter parsing for new signature: git_tree(repo_path_or_uri, [ref])
    auto params = ParseUnifiedGitParams(input, 1);  // ref parameter at index 1
    
    // Check for named parameter repo_path (backward compatibility)
    if (input.named_parameters.count("repo_path") && !StringUtil::StartsWith(params.repo_path_or_uri, "git://")) {
        params.resolved_repo_path = StringValue::Get(input.named_parameters.at("repo_path"));
    }
    
    // Use helper to define schema with repo_path as first column
    DefineGitTreeSchema(return_types, names);
    
    // Handle different parameter types
    if (input.inputs.empty()) {
        // Zero arguments - default to HEAD in current directory
        return make_uniq<GitTreeFunctionData>("HEAD", params.resolved_repo_path);
    }
    
    auto &first_param = input.inputs[0];
    
    if (first_param.type().id() == LogicalTypeId::VARCHAR) {
        // With unified signature, first parameter is repo_path_or_uri, ref comes from second parameter or URI
        
        if (IsCommitRange(params.ref)) {
            // Range mode: "HEAD~10..HEAD", "--all", etc.
            return make_uniq<GitTreeFunctionData>(params.ref, params.resolved_repo_path, true);
        } else {
            // Single commit mode
            return make_uniq<GitTreeFunctionData>(params.ref, params.resolved_repo_path);
        }
    } 
    else if (first_param.type().id() == LogicalTypeId::LIST) {
        // Array mode: ARRAY['HEAD', 'HEAD~1'] - not supported with new unified signature
        // This would only be valid for git_tree(LIST) with zero-arg signature 
        throw InternalException("git_tree: array mode not supported with unified signature. Use git_tree() with named parameter array.");
    }
    
    throw InternalException("git_tree: unsupported parameter type - expected VARCHAR");
}

// Helper function to process a single commit
static void ProcessSingleCommit(git_repository *repo, const string &ref, const string &repo_path,
                               vector<GitTreeRow> &rows) {
    git_object *obj = nullptr;
    if (git_revparse_single(&obj, repo, ref.c_str()) != 0) {
        const git_error *e = git_error_last();
        throw IOException("git_tree: failed to resolve ref '%s' in repository '%s': %s", 
                        ref, repo_path, e ? e->message : "Unknown error");
    }

    git_tree *tree = nullptr;
    git_commit *commit = nullptr;
    timestamp_t commit_date = timestamp_t(0);
    string commit_hash;

    if (git_object_type(obj) == GIT_OBJECT_COMMIT) {
        commit = reinterpret_cast<git_commit *>(obj);
        if (git_commit_tree(&tree, commit) != 0) {
            git_object_free(obj);
            throw IOException("git_tree: failed to get tree from commit");
        }
        
        // Get commit info
        const git_signature *sig = git_commit_author(commit);
        commit_date = Timestamp::FromEpochSeconds(sig->when.time);
        commit_hash = oid_to_hex(git_object_id(obj));
    } else if (git_object_type(obj) == GIT_OBJECT_TREE) {
        git_oid oid = *git_tree_id(reinterpret_cast<git_tree *>(obj));
        if (git_tree_lookup(&tree, repo, &oid) != 0) {
            git_object_free(obj);
            throw IOException("git_tree: failed to lookup tree");
        }
        commit_hash = oid_to_hex(&oid);
        commit_date = timestamp_t(0); // No timestamp for direct tree objects
    } else {
        git_object_free(obj);
        throw IOException("git_tree: ref is not a commit or tree");
    }

    traverse_tree(repo, tree, "", rows, commit_hash, commit_date, repo_path);

    git_tree_free(tree);
    git_object_free(obj);
}

// Bind function for LATERAL git_tree_each functions  
unique_ptr<FunctionData> GitTreeEachBind(ClientContext &context, TableFunctionBindInput &input,
                                        vector<LogicalType> &return_types, vector<string> &names) {
    
    // Set default parameters - repo_path_or_uri comes from input DataChunk at runtime
    string default_ref = "";  // Empty means use current branch, will be resolved at runtime
    if (input.inputs.size() > 1 && !input.inputs[1].IsNull()) {
        default_ref = StringValue::Get(input.inputs[1]);
    }
    
    // Use helper to define schema with repo_path as first column
    DefineGitTreeSchema(return_types, names);
    
    // Create function data with default ref - actual processing happens at runtime
    return make_uniq<GitTreeFunctionData>(default_ref, ".");  // Use "." as placeholder
}

// Bind function for LATERAL git_log_each functions - handles static parameters only
unique_ptr<FunctionData> GitLogEachBind(ClientContext &context, TableFunctionBindInput &input,
                                       vector<LogicalType> &return_types, vector<string> &names) {
    
    // Parse static parameters only (repo_path comes from LATERAL input at runtime)
    auto params = ParseLateralGitParams(input, 1);  // ref parameter at index 1 (optional)
    
    // Define return schema - same as GitLogBind
    return_types = {
        LogicalType::VARCHAR,    // repo_path
        LogicalType::VARCHAR,    // commit_hash
        LogicalType::VARCHAR,    // author_name  
        LogicalType::VARCHAR,    // author_email
        LogicalType::VARCHAR,    // committer_name
        LogicalType::VARCHAR,    // committer_email
        LogicalType::TIMESTAMP,  // author_date
        LogicalType::TIMESTAMP,  // commit_date
        LogicalType::VARCHAR,    // message
        LogicalType::INTEGER,    // parent_count
        LogicalType::VARCHAR     // tree_hash
    };
    
    names = {
        "repo_path", "commit_hash", "author_name", "author_email", "committer_name", "committer_email",
        "author_date", "commit_date", "message", "parent_count", "tree_hash"
    };
    
    // Create function data with placeholder values - real repo_path comes at runtime
    return make_uniq<GitLogFunctionData>(".", params.ref);  // Use "." as placeholder, store ref in resolved_repo_path field
}

// Bind function for LATERAL git_branches_each functions - handles static parameters only
unique_ptr<FunctionData> GitBranchesEachBind(ClientContext &context, TableFunctionBindInput &input,
                                            vector<LogicalType> &return_types, vector<string> &names) {
    
    // Parse static parameters only (repo_path comes from LATERAL input at runtime)  
    auto params = ParseLateralGitParams(input, 1);  // ref parameter at index 1 (optional)
    
    // Define return schema - same as GitBranchesBind
    return_types = {
        LogicalType::VARCHAR,  // repo_path
        LogicalType::VARCHAR,  // branch_name
        LogicalType::VARCHAR,  // commit_hash
        LogicalType::BOOLEAN,  // is_current
        LogicalType::BOOLEAN   // is_remote
    };
    
    names = {"repo_path", "branch_name", "commit_hash", "is_current", "is_remote"};
    
    // Create function data with placeholder values - real repo_path comes at runtime
    return make_uniq<GitBranchesFunctionData>(".", ".");  // Use "." as placeholder
}

// Bind function for LATERAL git_tags_each functions - handles static parameters only
unique_ptr<FunctionData> GitTagsEachBind(ClientContext &context, TableFunctionBindInput &input,
                                        vector<LogicalType> &return_types, vector<string> &names) {
    
    // Parse static parameters only (repo_path comes from LATERAL input at runtime)
    auto params = ParseLateralGitParams(input, 1);  // ref parameter at index 1 (optional)
    
    // Define return schema - same as GitTagsBind
    return_types = {
        LogicalType::VARCHAR,    // repo_path
        LogicalType::VARCHAR,    // tag_name
        LogicalType::VARCHAR,    // commit_hash
        LogicalType::VARCHAR,    // tagger_name
        LogicalType::TIMESTAMP,  // tagger_date
        LogicalType::VARCHAR,    // message
        LogicalType::BOOLEAN     // is_annotated
    };
    
    names = {"repo_path", "tag_name", "commit_hash", "tagger_name", "tagger_date", "message", "is_annotated"};
    
    // Create function data with placeholder values - real repo_path comes at runtime
    return make_uniq<GitTagsFunctionData>(".", ".");  // Use "." as placeholder
}

unique_ptr<GlobalTableFunctionState> GitTreeInitGlobal(ClientContext &context, TableFunctionInitInput &input) {
    auto &bind_data = const_cast<GitTreeFunctionData&>(input.bind_data->Cast<GitTreeFunctionData>());
    
    // libgit2 is initialized at extension load time
    
    git_repository *repo = nullptr;
    int error = git_repository_open(&repo, bind_data.repo_path.c_str());
    if (error != 0) {
        const git_error *e = git_error_last();
        throw IOException("git_tree: failed to open git repository '%s': %s", 
                        bind_data.repo_path, e ? e->message : "Unknown error");
    }

    vector<GitTreeRow> rows;
    rows.reserve(1024);

    try {
        switch (bind_data.mode) {
            case GitTreeMode::SINGLE: {
                ProcessSingleCommit(repo, bind_data.ref, bind_data.repo_path, rows);
                break;
            }
            case GitTreeMode::RANGE: {
                // For now, implement basic range support
                // TODO: Implement full git range parsing (HEAD~10..HEAD, --all, etc.)
                if (bind_data.commit_range == "--all") {
                    // Process all reachable commits
                    git_revwalk *walk = nullptr;
                    git_revwalk_new(&walk, repo);
                    git_revwalk_push_head(walk);
                    
                    git_oid oid;
                    while (git_revwalk_next(&oid, walk) == 0) {
                        string commit_hash = oid_to_hex(&oid);
                        ProcessSingleCommit(repo, commit_hash, bind_data.repo_path, rows);
                    }
                    git_revwalk_free(walk);
                } else {
                    // For other ranges, just process as single commit for now
                    ProcessSingleCommit(repo, bind_data.commit_range, bind_data.repo_path, rows);
                }
                break;
            }
        }
    } catch (...) {
        git_repository_free(repo);
        throw;
    }

    // Store rows in bind_data so they persist
    bind_data.rows = std::move(rows);

    git_repository_free(repo);

    return make_uniq<GlobalTableFunctionState>();
}

void GitTreeFunction(ClientContext &context, TableFunctionInput &data_p, DataChunk &output) {
    auto &bind_data = const_cast<GitTreeFunctionData&>(data_p.bind_data->Cast<GitTreeFunctionData>());
    
    idx_t remaining = bind_data.rows.size() - bind_data.current_index;
    if (remaining == 0) {
        output.SetCardinality(0);
        return;
    }

    const idx_t count = MinValue<idx_t>(remaining, STANDARD_VECTOR_SIZE);
    
    for (idx_t i = 0; i < count; i++) {
        auto &row = bind_data.rows[bind_data.current_index + i];
        OutputGitTreeRow(output, i, row, bind_data.repo_path);
    }

    output.SetCardinality(count);
    bind_data.current_index += count;
}


//===--------------------------------------------------------------------===//
// Git Parents Function  
//===--------------------------------------------------------------------===//

GitParentsFunctionData::GitParentsFunctionData(const string &ref, const string &repo_path, bool all_refs)
    : ref(ref), repo_path(repo_path), all_refs(all_refs), current_index(0) {
}

unique_ptr<FunctionData> GitParentsBind(ClientContext &context, TableFunctionBindInput &input,
                                       vector<LogicalType> &return_types, vector<string> &names) {
    bool all_refs = false;
    
    // Use unified parameter parsing for new signature: git_parents(repo_path_or_uri, [ref])
    auto params = ParseUnifiedGitParams(input, 1);  // ref parameter at index 1
    
    // Check for named parameters
    if (input.named_parameters.count("repo_path") && !StringUtil::StartsWith(params.repo_path_or_uri, "git://")) {
        params.resolved_repo_path = StringValue::Get(input.named_parameters.at("repo_path"));
    }
    if (input.named_parameters.count("all_refs")) {
        all_refs = BooleanValue::Get(input.named_parameters.at("all_refs"));
    }
    
    // Use helper to define schema with repo_path as first column
    DefineGitParentsSchema(return_types, names);
    
    return make_uniq<GitParentsFunctionData>(params.ref, params.resolved_repo_path, all_refs);
}

unique_ptr<GlobalTableFunctionState> GitParentsInitGlobal(ClientContext &context, TableFunctionInitInput &input) {
    auto &bind_data = const_cast<GitParentsFunctionData&>(input.bind_data->Cast<GitParentsFunctionData>());
    
    // libgit2 is initialized at extension load time
    
    git_repository *repo = nullptr;
    int error = git_repository_open(&repo, bind_data.repo_path.c_str());
    if (error != 0) {
        const git_error *e = git_error_last();
        throw IOException("git_parents: failed to open git repository '%s': %s", 
                        bind_data.repo_path, e ? e->message : "Unknown error");
    }

    git_revwalk *walk = nullptr;
    git_revwalk_new(&walk, repo);
    git_revwalk_sorting(walk, GIT_SORT_TOPOLOGICAL | GIT_SORT_TIME);

    if (bind_data.all_refs) {
        git_reference_iterator *it = nullptr;
        git_reference_iterator_new(&it, repo);
        git_reference *ref;
        while (!git_reference_next(&ref, it)) {
            const git_oid *target = git_reference_target(ref);
            if (target) {
                git_revwalk_push(walk, target);
            }
        }
        git_reference_iterator_free(it);
    } else {
        git_object *obj = nullptr;
        if (git_revparse_single(&obj, repo, bind_data.ref.c_str()) != 0) {
            const git_error *e = git_error_last();
            git_revwalk_free(walk);
            git_repository_free(repo);
                throw IOException("git_parents: cannot resolve ref '%s' in repository '%s': %s", 
                            bind_data.ref, bind_data.repo_path, e ? e->message : "Unknown error");
        }
        git_oid oid = *git_object_id(obj);
        git_revwalk_push(walk, &oid);
        git_object_free(obj);
    }

    vector<GitParentsRow> rows;
    git_oid oid;
    while (!git_revwalk_next(&oid, walk)) {
        git_commit *commit = nullptr;
        if (git_commit_lookup(&commit, repo, &oid) != 0) {
            continue;
        }
        
        unsigned int parent_count = git_commit_parentcount(commit);
        for (unsigned int i = 0; i < parent_count; i++) {
            const git_oid *parent_oid = git_commit_parent_id(commit, i);
            rows.push_back(GitParentsRow{
                oid_to_hex(&oid), 
                oid_to_hex(parent_oid), 
                static_cast<int32_t>(i)
            });
        }
        git_commit_free(commit);
    }

    // Store rows in bind_data
    bind_data.rows = std::move(rows);

    git_revwalk_free(walk);
    git_repository_free(repo);

    return make_uniq<GlobalTableFunctionState>();
}

void GitParentsFunction(ClientContext &context, TableFunctionInput &data_p, DataChunk &output) {
    auto &bind_data = const_cast<GitParentsFunctionData&>(data_p.bind_data->Cast<GitParentsFunctionData>());
    
    idx_t remaining = bind_data.rows.size() - bind_data.current_index;
    if (remaining == 0) {
        output.SetCardinality(0);
        return;
    }

    const idx_t count = MinValue<idx_t>(remaining, STANDARD_VECTOR_SIZE);
    
    for (idx_t i = 0; i < count; i++) {
        auto &row = bind_data.rows[bind_data.current_index + i];
        OutputGitParentsRow(output, i, row, bind_data.repo_path);
    }

    output.SetCardinality(count);
    bind_data.current_index += count;
}

//===--------------------------------------------------------------------===//
// Registration
//===--------------------------------------------------------------------===//

// Helper function for LATERAL git_log_each processing - processes entire git log for a repository path
static void ProcessLogCommitForInOut(const string &input_repo_path, const string &bind_repo_path, vector<GitLogRow> &rows) {
    // Use input_repo_path from LATERAL context, or bind_repo_path as fallback
    string repo_path = input_repo_path.empty() ? bind_repo_path : input_repo_path;
    
    // libgit2 is initialized at extension load time
    
    // Use GitPath::Parse to resolve repository path  
    string resolved_repo_path;
    try {
        auto git_path = GitPath::Parse("git://" + repo_path + "@HEAD");  
        resolved_repo_path = git_path.repository_path;
    } catch (const std::exception &e) {
        throw IOException("Failed to resolve repository path '%s': %s", repo_path, e.what());
    }
    
    git_repository *repo = nullptr;
    int error = git_repository_open(&repo, resolved_repo_path.c_str());
    if (error != 0) {
        const git_error *e = git_error_last();
        throw IOException("Failed to open repository '%s': %s", 
                        repo_path, e ? e->message : "Unknown error");
    }
    
    // Create revwalk
    git_revwalk *walker = nullptr;
    error = git_revwalk_new(&walker, repo);
    if (error != 0) {
        git_repository_free(repo);
        const git_error *e = git_error_last();
        throw IOException("Failed to create revwalk: %s", e ? e->message : "Unknown error");
    }
    
    // Push HEAD (like git_log does) - process entire log
    error = git_revwalk_push_head(walker);
    if (error != 0) {
        git_revwalk_free(walker);
        git_repository_free(repo);
        const git_error *e = git_error_last();
        throw IOException("Failed to push HEAD: %s", e ? e->message : "Unknown error");
        return;
    }
    
    // Walk commits
    git_oid commit_oid;
    while (git_revwalk_next(&commit_oid, walker) == 0) {
        git_commit *commit = nullptr;
        error = git_commit_lookup(&commit, repo, &commit_oid);
        if (error != 0) {
            continue; // Skip invalid commits
        }
        
        GitLogRow row;
        row.repo_path = repo_path;
        
        // Get commit hash
        char hash_str[GIT_OID_HEXSZ + 1];
        git_oid_tostr(hash_str, sizeof(hash_str), &commit_oid);
        row.commit_hash = hash_str;
        
        // Get author info
        const git_signature *author = git_commit_author(commit);
        row.author_name = author->name ? author->name : "";
        row.author_email = author->email ? author->email : "";
        
        // Get committer info
        const git_signature *committer = git_commit_committer(commit);
        row.committer_name = committer->name ? committer->name : "";
        row.committer_email = committer->email ? committer->email : "";
        
        // Get timestamps
        row.author_date = Timestamp::FromEpochSeconds(author->when.time);
        row.commit_date = Timestamp::FromEpochSeconds(committer->when.time);
        
        // Get commit message
        const char *message = git_commit_message(commit);
        row.message = message ? message : "";
        
        // Get parent count
        row.parent_count = git_commit_parentcount(commit);
        
        // Get tree hash
        const git_oid *tree_oid = git_commit_tree_id(commit);
        char tree_hash[GIT_OID_HEXSZ + 1];
        git_oid_tostr(tree_hash, sizeof(tree_hash), tree_oid);
        row.tree_hash = tree_hash;
        
        rows.push_back(row);
        git_commit_free(commit);
    }
    
    git_revwalk_free(walker);
    git_repository_free(repo);
}

// LATERAL git_log_each function - processes dynamic commit refs
static OperatorResultType GitLogEachFunction(ExecutionContext &context, TableFunctionInput &data_p, 
                                           DataChunk &input, DataChunk &output) {
    auto &bind_data = data_p.bind_data->Cast<GitLogFunctionData>();
    auto &state = data_p.local_state->Cast<GitLogLocalState>();
    
    // Declare resolved_repo_path at function scope so it's accessible in output loop
    string resolved_repo_path;
    
    while (true) {
        if (!state.initialized_row) {
            // initialize for the current input row
            if (state.current_input_row >= input.size()) {
                // ran out of rows
                state.current_input_row = 0;
                state.initialized_row = false;
                return OperatorResultType::NEED_MORE_INPUT;
            }
            
            // LATERAL function: extract repo_path_or_uri from input DataChunk
            input.Flatten();
            
            // Check if input has columns and data
            if (input.ColumnCount() == 0) {
                throw BinderException("git_log_each: no input columns available");
            }
            
            // Check if the input is null
            if (FlatVector::IsNull(input.data[0], state.current_input_row)) {
                // Move to next input row if null
                state.current_input_row++;
                state.initialized_row = false;
                continue;
            }
            
            // Extract repo_path_or_uri from input DataChunk - direct string_t access
            auto data = FlatVector::GetData<string_t>(input.data[0]);
            if (!data) {
                throw BinderException("git_log_each: no string data in input column");
            }
            
            // Get the string_t directly and convert to string
            auto string_t_value = data[state.current_input_row];
            string repo_path_or_uri(string_t_value.GetData(), string_t_value.GetSize());
            
            if (repo_path_or_uri.empty()) {
                throw BinderException("git_log_each: received empty repo_path_or_uri from input");
            }
            
            // Apply unified parameter processing at runtime
            // Combine LATERAL input (repo_path) with bind-time parameters (ref stored in resolved_repo_path field)
            string resolved_file_path, final_ref = bind_data.resolved_repo_path;
            
            if (StringUtil::StartsWith(repo_path_or_uri, "git://")) {
                // git:// URI - parse it
                try {
                    auto git_path = GitPath::Parse(repo_path_or_uri);
                    resolved_repo_path = git_path.repository_path;
                    resolved_file_path = git_path.file_path;
                    
                    // Check for ref conflict validation
                    if (!git_path.revision.empty() && bind_data.resolved_repo_path != "HEAD") {
                        throw BinderException("git_log_each: Conflicting ref specifications: git:// URI contains '@%s' but function parameter specifies '%s'", 
                                            git_path.revision, bind_data.resolved_repo_path);
                    }
                    if (!git_path.revision.empty()) {
                        final_ref = git_path.revision;
                    }
                } catch (const std::exception &e) {
                    throw BinderException("git_log_each: Failed to parse git:// URI '%s': %s", repo_path_or_uri, e.what());
                }
            } else {
                // Filesystem path - use repository discovery
                try {
                    auto git_path = GitPath::Parse("git://" + repo_path_or_uri + "@" + final_ref);
                    resolved_repo_path = git_path.repository_path;
                    resolved_file_path = git_path.file_path;
                } catch (const std::exception &e) {
                    throw BinderException("git_log_each: Failed to resolve repository path '%s': %s", repo_path_or_uri, e.what());
                }
            }
            
            // Process the git log using the resolved parameters
            state.current_rows.clear();
            ProcessLogCommitForInOut(resolved_repo_path, final_ref, state.current_rows);
            
            state.initialized_row = true;
            state.current_output_row = 0;
        }
        
        // Output rows for current input
        idx_t output_count = 0;
        while (output_count < STANDARD_VECTOR_SIZE && 
               state.current_output_row < state.current_rows.size()) {
            
            auto &row = state.current_rows[state.current_output_row];
            
            // Fill output row with git log data
            output.SetValue(0, output_count, Value(resolved_repo_path));
            output.SetValue(1, output_count, Value(row.commit_hash));
            output.SetValue(2, output_count, Value(row.author_name));  
            output.SetValue(3, output_count, Value(row.author_email));
            output.SetValue(4, output_count, Value(row.committer_name));
            output.SetValue(5, output_count, Value(row.committer_email));
            output.SetValue(6, output_count, Value::TIMESTAMP(row.author_date));
            output.SetValue(7, output_count, Value::TIMESTAMP(row.commit_date));
            output.SetValue(8, output_count, Value(row.message));
            output.SetValue(9, output_count, Value::INTEGER(row.parent_count));
            output.SetValue(10, output_count, Value(row.tree_hash));
            
            output_count++;
            state.current_output_row++;
        }
        
        output.SetCardinality(output_count);
        
        // Check if we're done with current input row
        if (state.current_output_row >= state.current_rows.size()) {
            state.current_input_row++;
            state.initialized_row = false;
        }
        
        return OperatorResultType::HAVE_MORE_OUTPUT;
    }
}

// Helper function for LATERAL git_branches_each processing - processes entire git branches for a repository path
static void ProcessBranchesForInOut(const string &input_repo_path, const string &bind_repo_path, vector<GitBranchesRow> &rows) {
    // Use input_repo_path from LATERAL context, or bind_repo_path as fallback
    string repo_path = input_repo_path.empty() ? bind_repo_path : input_repo_path;
    
    // Use GitPath::Parse for repository discovery
    string resolved_repo_path;
    try {
        auto git_path = GitPath::Parse("git://" + repo_path + "@HEAD");
        resolved_repo_path = git_path.repository_path;
    } catch (const std::exception &e) {
        throw IOException("Failed to resolve repository path '%s': %s", repo_path, e.what());
    }
    
    git_repository *repo = nullptr;
    git_branch_iterator *iterator = nullptr;
    
    try {
        // Open repository
        int error = git_repository_open(&repo, resolved_repo_path.c_str());
        if (error != 0) {
            const git_error *e = git_error_last();
            throw IOException("Failed to open git repository '%s': %s", 
                            resolved_repo_path, e ? e->message : "Unknown error");
        }
        
        // Create branch iterator
        error = git_branch_iterator_new(&iterator, repo, GIT_BRANCH_ALL);
        if (error != 0) {
            const git_error *e = git_error_last();
            throw IOException("Failed to create branch iterator: %s", e ? e->message : "Unknown error");
        }
        
        // Iterate through branches
        git_reference *ref = nullptr;
        git_branch_t branch_type;
        
        while (git_branch_next(&ref, &branch_type, iterator) == 0) {
            GitBranchesRow row;
            row.repo_path = repo_path;
            
            // Get branch name
            const char *branch_name = nullptr;
            git_branch_name(&branch_name, ref);
            row.branch_name = branch_name ? branch_name : "";
            
            // Get commit hash
            const git_oid *oid = git_reference_target(ref);
            if (oid) {
                char hash_str[GIT_OID_HEXSZ + 1];
                git_oid_tostr(hash_str, sizeof(hash_str), oid);
                row.commit_hash = hash_str;
            } else {
                row.commit_hash = "";
            }
            
            // Check if current branch
            row.is_current = (git_branch_is_head(ref) == 1);
            
            // Check if remote branch
            row.is_remote = (branch_type == GIT_BRANCH_REMOTE);
            
            rows.push_back(row);
            
            git_reference_free(ref);
            ref = nullptr;
        }
        
    } catch (...) {
        // Cleanup on exception
        if (iterator) {
            git_branch_iterator_free(iterator);
            iterator = nullptr;
        }
        if (repo) {
            git_repository_free(repo);
            repo = nullptr;
        }
        throw;
    }
    
    // Normal cleanup
    if (iterator) {
        git_branch_iterator_free(iterator);
        iterator = nullptr;
    }
    if (repo) {
        git_repository_free(repo);
        repo = nullptr;
    }
}

// LATERAL git_branches_each function - processes dynamic repository paths
static OperatorResultType GitBranchesEachFunction(ExecutionContext &context, TableFunctionInput &data_p, 
                                                 DataChunk &input, DataChunk &output) {
    auto &state = data_p.local_state->Cast<GitBranchesLocalState>();
    
    // Declare resolved_repo_path at function scope so it's accessible in output loop
    string resolved_repo_path;
    
    while (true) {
        if (!state.initialized_row) {
            if (state.current_input_row >= input.size()) {
                state.current_input_row = 0;
                state.initialized_row = false;
                return OperatorResultType::NEED_MORE_INPUT;
            }
            
            // LATERAL function: extract repo_path_or_uri from input DataChunk
            input.Flatten();
            
            // Check if input has columns and data
            if (input.ColumnCount() == 0) {
                throw BinderException("git_branches_each: no input columns available");
            }
            
            // Check if the input is null
            if (FlatVector::IsNull(input.data[0], state.current_input_row)) {
                // Move to next input row if null
                state.current_input_row++;
                state.initialized_row = false;
                continue;
            }
            
            // Extract repo_path_or_uri from input DataChunk - direct string_t access
            auto data = FlatVector::GetData<string_t>(input.data[0]);
            if (!data) {
                throw BinderException("git_branches_each: no string data in input column");
            }
            
            // Get the string_t directly and convert to string
            auto string_t_value = data[state.current_input_row];
            string repo_path_or_uri(string_t_value.GetData(), string_t_value.GetSize());
            
            if (repo_path_or_uri.empty()) {
                throw BinderException("git_branches_each: received empty repo_path_or_uri from input");
            }
            
            // Apply unified parameter processing at runtime
            string resolved_file_path;
            
            if (StringUtil::StartsWith(repo_path_or_uri, "git://")) {
                // git:// URI - parse it
                try {
                    auto git_path = GitPath::Parse(repo_path_or_uri);
                    resolved_repo_path = git_path.repository_path;
                    resolved_file_path = git_path.file_path;
                } catch (const std::exception &e) {
                    throw BinderException("git_branches_each: Failed to parse git:// URI '%s': %s", repo_path_or_uri, e.what());
                }
            } else {
                // Filesystem path - use repository discovery
                try {
                    auto git_path = GitPath::Parse("git://" + repo_path_or_uri + "@HEAD");
                    resolved_repo_path = git_path.repository_path;
                    resolved_file_path = git_path.file_path;
                } catch (const std::exception &e) {
                    throw BinderException("git_branches_each: Failed to resolve repository path '%s': %s", repo_path_or_uri, e.what());
                }
            }
            
            // Process the git branches using the resolved parameters
            state.current_rows.clear();
            ProcessBranchesForInOut(resolved_repo_path, ".", state.current_rows);
            
            state.initialized_row = true;
            state.current_output_row = 0;
        }
        
        idx_t output_count = 0;
        while (output_count < STANDARD_VECTOR_SIZE && 
               state.current_output_row < state.current_rows.size()) {
            
            auto &row = state.current_rows[state.current_output_row];
            
            output.SetValue(0, output_count, Value(resolved_repo_path));
            output.SetValue(1, output_count, Value(row.branch_name));
            output.SetValue(2, output_count, Value(row.commit_hash));
            output.SetValue(3, output_count, Value(row.is_current));
            output.SetValue(4, output_count, Value(row.is_remote));
            
            output_count++;
            state.current_output_row++;
        }
        
        output.SetCardinality(output_count);
        
        if (state.current_output_row >= state.current_rows.size()) {
            state.current_input_row++;
            state.initialized_row = false;
        }
        
        return OperatorResultType::HAVE_MORE_OUTPUT;
    }
}

// Helper function for LATERAL git_tags_each processing - processes entire git tags for a repository path  
static void ProcessTagsForInOut(const string &input_repo_path, const string &bind_repo_path, vector<GitTagsRow> &rows) {
    // Use input_repo_path from LATERAL context, or bind_repo_path as fallback
    string repo_path = input_repo_path.empty() ? bind_repo_path : input_repo_path;
    
    // Use GitPath::Parse for repository discovery
    string resolved_repo_path;
    try {
        auto git_path = GitPath::Parse("git://" + repo_path + "@HEAD");
        resolved_repo_path = git_path.repository_path;
    } catch (const std::exception &e) {
        throw IOException("Failed to resolve repository path '%s': %s", repo_path, e.what());
    }
    
    git_repository *repo = nullptr;
    vector<string> tag_names;
    
    try {
        // Open repository
        int error = git_repository_open(&repo, resolved_repo_path.c_str());
        if (error != 0) {
            const git_error *e = git_error_last();
            throw IOException("Failed to open git repository '%s': %s", 
                            resolved_repo_path, e ? e->message : "Unknown error");
        }
        
        // Get all tags
        error = git_tag_foreach(repo, tag_foreach_cb, &tag_names);
        if (error != 0) {
            const git_error *e = git_error_last();
            throw IOException("Failed to list tags: %s", e ? e->message : "Unknown error");
        }
        
        // Process each tag
        for (const string &tag_name : tag_names) {
            GitTagsRow row;
            row.repo_path = repo_path;
            row.tag_name = tag_name;
            
            // Look up tag reference
            git_reference *tag_ref = nullptr;
            string full_name = "refs/tags/" + tag_name;
            error = git_reference_lookup(&tag_ref, repo, full_name.c_str());
            if (error == 0) {
                const git_oid *oid = git_reference_target(tag_ref);
                if (oid) {
                    char hash_str[GIT_OID_HEXSZ + 1];
                    git_oid_tostr(hash_str, sizeof(hash_str), oid);
                    row.commit_hash = hash_str;
                    
                    // Try to get tag object for annotation info
                    git_tag *tag_obj = nullptr;
                    bool is_annotated = false;
                    if (git_tag_lookup(&tag_obj, repo, oid) == 0) {
                        is_annotated = true;
                        
                        const git_signature *tagger = git_tag_tagger(tag_obj);
                        if (tagger) {
                            row.tagger_name = tagger->name ? tagger->name : "";
                            row.tagger_date = Timestamp::FromEpochSeconds(tagger->when.time);
                        } else {
                            row.tagger_name = "";
                            row.tagger_date = timestamp_t(0);
                        }
                        
                        const char *message = git_tag_message(tag_obj);
                        row.message = message ? message : "";
                        
                        git_tag_free(tag_obj);
                        tag_obj = nullptr;
                    } else {
                        // Lightweight tag
                        row.tagger_name = "";
                        row.tagger_date = timestamp_t(0);
                        row.message = "";
                    }
                    
                    row.is_annotated = is_annotated;
                } else {
                    row.commit_hash = "";
                    row.tagger_name = "";
                    row.tagger_date = timestamp_t(0);
                    row.message = "";
                    row.is_annotated = false;
                }
                
                rows.push_back(row);
                git_reference_free(tag_ref);
                tag_ref = nullptr;
            }
        }
        
    } catch (...) {
        // Cleanup on exception
        if (repo) {
            git_repository_free(repo);
            repo = nullptr;
        }
        throw;
    }
    
    // Normal cleanup
    if (repo) {
        git_repository_free(repo);
        repo = nullptr;
    }
}

// LATERAL git_tags_each function - processes dynamic repository paths
static OperatorResultType GitTagsEachFunction(ExecutionContext &context, TableFunctionInput &data_p, 
                                             DataChunk &input, DataChunk &output) {
    auto &bind_data = data_p.bind_data->Cast<GitTagsFunctionData>();
    auto &state = data_p.local_state->Cast<GitTagsLocalState>();
    
    // Declare resolved_repo_path at function scope so it's accessible in output loop
    string resolved_repo_path;
    
    while (true) {
        if (!state.initialized_row) {
            if (state.current_input_row >= input.size()) {
                state.current_input_row = 0;
                state.initialized_row = false;
                return OperatorResultType::NEED_MORE_INPUT;
            }
            
            // LATERAL function: extract repo_path_or_uri from input DataChunk
            input.Flatten();
            
            // Check if input has columns and data
            if (input.ColumnCount() == 0) {
                throw BinderException("git_tags_each: no input columns available");
            }
            
            // Check if the input is null
            if (FlatVector::IsNull(input.data[0], state.current_input_row)) {
                // Move to next input row if null
                state.current_input_row++;
                state.initialized_row = false;
                continue;
            }
            
            // Extract repo_path_or_uri from input DataChunk - direct string_t access
            auto data = FlatVector::GetData<string_t>(input.data[0]);
            if (!data) {
                throw BinderException("git_tags_each: no string data in input column");
            }
            
            // Get the string_t directly and convert to string
            auto string_t_value = data[state.current_input_row];
            string repo_path_or_uri(string_t_value.GetData(), string_t_value.GetSize());
            
            if (repo_path_or_uri.empty()) {
                throw BinderException("git_tags_each: received empty repo_path_or_uri from input");
            }
            
            // Apply unified parameter processing at runtime
            string resolved_file_path;
            
            if (StringUtil::StartsWith(repo_path_or_uri, "git://")) {
                // git:// URI - parse it
                try {
                    auto git_path = GitPath::Parse(repo_path_or_uri);
                    resolved_repo_path = git_path.repository_path;
                    resolved_file_path = git_path.file_path;
                } catch (const std::exception &e) {
                    throw BinderException("git_tags_each: Failed to parse git:// URI '%s': %s", repo_path_or_uri, e.what());
                }
            } else {
                // Filesystem path - use repository discovery
                try {
                    auto git_path = GitPath::Parse("git://" + repo_path_or_uri + "@HEAD");
                    resolved_repo_path = git_path.repository_path;
                    resolved_file_path = git_path.file_path;
                } catch (const std::exception &e) {
                    throw BinderException("git_tags_each: Failed to resolve repository path '%s': %s", repo_path_or_uri, e.what());
                }
            }
            
            // Process the git tags using the resolved parameters
            state.current_rows.clear();
            ProcessTagsForInOut(resolved_repo_path, ".", state.current_rows);
            
            state.initialized_row = true;
            state.current_output_row = 0;
        }
        
        idx_t output_count = 0;
        while (output_count < STANDARD_VECTOR_SIZE && 
               state.current_output_row < state.current_rows.size()) {
            
            auto &row = state.current_rows[state.current_output_row];
            
            output.SetValue(0, output_count, Value(resolved_repo_path));
            output.SetValue(1, output_count, Value(row.tag_name));
            output.SetValue(2, output_count, Value(row.commit_hash));
            output.SetValue(3, output_count, Value(row.tagger_name));
            output.SetValue(4, output_count, Value::TIMESTAMP(row.tagger_date));
            output.SetValue(5, output_count, Value(row.message));
            output.SetValue(6, output_count, Value(row.is_annotated));
            
            output_count++;
            state.current_output_row++;
        }
        
        output.SetCardinality(output_count);
        
        if (state.current_output_row >= state.current_rows.size()) {
            state.current_input_row++;
            state.initialized_row = false;
        }
        
        return OperatorResultType::HAVE_MORE_OUTPUT;
    }
}

void RegisterGitLogFunction(DatabaseInstance &db) {
    // Single-argument version (existing)
    TableFunction git_log_func("git_log", {LogicalType::VARCHAR}, GitLogFunction, GitLogBind, GitLogInitGlobal);
    git_log_func.named_parameters["repo_path"] = LogicalType::VARCHAR;
    ExtensionUtil::RegisterFunction(db, git_log_func);
    
    // Zero-argument version (defaults to current directory)
    TableFunction git_log_func_zero("git_log", {}, GitLogFunction, GitLogBind, GitLogInitGlobal);
    git_log_func_zero.named_parameters["repo_path"] = LogicalType::VARCHAR;
    ExtensionUtil::RegisterFunction(db, git_log_func_zero);
    
    // LATERAL git_log_each function (commit ref comes from LATERAL context) - ONLY for dynamic input
    TableFunctionSet git_log_each_set("git_log_each");
    
    // Version that takes commit ref as first parameter (for LATERAL context)
    TableFunction git_log_each_single({LogicalType::VARCHAR}, nullptr, GitLogEachBind, nullptr, GitLogLocalInit);
    git_log_each_single.in_out_function = GitLogEachFunction;
    git_log_each_single.named_parameters["repo_path"] = LogicalType::VARCHAR;
    git_log_each_set.AddFunction(git_log_each_single);
    
    // Two-argument version (ref, repo_path)
    TableFunction git_log_each_two({LogicalType::VARCHAR, LogicalType::VARCHAR}, nullptr, GitLogEachBind, nullptr, GitLogLocalInit);
    git_log_each_two.in_out_function = GitLogEachFunction;
    git_log_each_two.named_parameters["repo_path"] = LogicalType::VARCHAR;
    git_log_each_set.AddFunction(git_log_each_two);
    
    ExtensionUtil::RegisterFunction(db, git_log_each_set);
}

void RegisterGitBranchesFunction(DatabaseInstance &db) {
    // Single-argument version (existing)
    TableFunction git_branches_func("git_branches", {LogicalType::VARCHAR}, GitBranchesFunction, GitBranchesBind, GitBranchesInitGlobal);
    git_branches_func.named_parameters["repo_path"] = LogicalType::VARCHAR;
    ExtensionUtil::RegisterFunction(db, git_branches_func);
    
    // Zero-argument version (defaults to current directory)
    TableFunction git_branches_func_zero("git_branches", {}, GitBranchesFunction, GitBranchesBind, GitBranchesInitGlobal);
    git_branches_func_zero.named_parameters["repo_path"] = LogicalType::VARCHAR;
    ExtensionUtil::RegisterFunction(db, git_branches_func_zero);
    
    // LATERAL git_branches_each function (repository path comes from LATERAL context) - ONLY for dynamic input
    TableFunctionSet git_branches_each_set("git_branches_each");
    
    // Version that takes repository path as first parameter (for LATERAL context)
    TableFunction git_branches_each_single({LogicalType::VARCHAR}, nullptr, GitBranchesEachBind, nullptr, GitBranchesLocalInit);
    git_branches_each_single.in_out_function = GitBranchesEachFunction;
    git_branches_each_single.named_parameters["repo_path"] = LogicalType::VARCHAR;
    git_branches_each_set.AddFunction(git_branches_each_single);
    
    // Two-argument version (repo_path, repo_path)
    TableFunction git_branches_each_two({LogicalType::VARCHAR, LogicalType::VARCHAR}, nullptr, GitBranchesEachBind, nullptr, GitBranchesLocalInit);
    git_branches_each_two.in_out_function = GitBranchesEachFunction;
    git_branches_each_two.named_parameters["repo_path"] = LogicalType::VARCHAR;
    git_branches_each_set.AddFunction(git_branches_each_two);
    
    ExtensionUtil::RegisterFunction(db, git_branches_each_set);
}

void RegisterGitTagsFunction(DatabaseInstance &db) {
    // Single-argument version (existing)
    TableFunction git_tags_func("git_tags", {LogicalType::VARCHAR}, GitTagsFunction, GitTagsBind, GitTagsInitGlobal);
    git_tags_func.named_parameters["repo_path"] = LogicalType::VARCHAR;
    ExtensionUtil::RegisterFunction(db, git_tags_func);
    
    // Zero-argument version (defaults to current directory)
    TableFunction git_tags_func_zero("git_tags", {}, GitTagsFunction, GitTagsBind, GitTagsInitGlobal);
    git_tags_func_zero.named_parameters["repo_path"] = LogicalType::VARCHAR;
    ExtensionUtil::RegisterFunction(db, git_tags_func_zero);
    
    // LATERAL git_tags_each function (repository path comes from LATERAL context) - ONLY for dynamic input
    TableFunctionSet git_tags_each_set("git_tags_each");
    
    // Version that takes repository path as first parameter (for LATERAL context)
    TableFunction git_tags_each_single({LogicalType::VARCHAR}, nullptr, GitTagsEachBind, nullptr, GitTagsLocalInit);
    git_tags_each_single.in_out_function = GitTagsEachFunction;
    git_tags_each_single.named_parameters["repo_path"] = LogicalType::VARCHAR;
    git_tags_each_set.AddFunction(git_tags_each_single);
    
    // Two-argument version (repo_path, repo_path)
    TableFunction git_tags_each_two({LogicalType::VARCHAR, LogicalType::VARCHAR}, nullptr, GitTagsEachBind, nullptr, GitTagsLocalInit);
    git_tags_each_two.in_out_function = GitTagsEachFunction;
    git_tags_each_two.named_parameters["repo_path"] = LogicalType::VARCHAR;
    git_tags_each_set.AddFunction(git_tags_each_two);
    
    ExtensionUtil::RegisterFunction(db, git_tags_each_set);
}

//===--------------------------------------------------------------------===//
// Git Tree Each LATERAL Function (for dynamic parameters)
//===--------------------------------------------------------------------===//

unique_ptr<LocalTableFunctionState> GitTreeLocalInit(ExecutionContext &context,
                                                     TableFunctionInitInput &input,
                                                     GlobalTableFunctionState *global_state) {
    return make_uniq<GitTreeLocalState>();
}

// Helper function for LATERAL git_tree_each processing
static void ProcessTreeCommitForInOut(const string &commit_ref, const string &repo_path, vector<GitTreeRow> &rows) {
    // libgit2 is initialized at extension load time
    git_repository *repo = nullptr;
    
    try {
        if (git_repository_open(&repo, repo_path.c_str()) != 0) {
                return;
        }
        
        ProcessSingleCommit(repo, commit_ref, repo_path, rows);
        git_repository_free(repo);
    } catch (...) {
        if (repo) {
            git_repository_free(repo);
        }
    }
    
}

static OperatorResultType GitTreeEachFunction(ExecutionContext &context, TableFunctionInput &data_p,
                                              DataChunk &input, DataChunk &output) {
    auto &bind_data = data_p.bind_data->Cast<GitTreeFunctionData>();
    auto &state = data_p.local_state->Cast<GitTreeLocalState>();
    
    // Declare resolved_repo_path at function scope so it's accessible in output loop
    string resolved_repo_path;
    
    while (true) {
        if (!state.initialized_row) {
            // initialize for the current input row
            if (state.current_input_row >= input.size()) {
                // ran out of rows
                state.current_input_row = 0;
                state.initialized_row = false;
                return OperatorResultType::NEED_MORE_INPUT;
            }
            
            // LATERAL function: extract repo_path_or_uri from input DataChunk
            input.Flatten();
            
            // Check if input has columns and data
            if (input.ColumnCount() == 0) {
                throw BinderException("git_tree_each: no input columns available");
            }
            
            // Check if the input is null
            if (FlatVector::IsNull(input.data[0], state.current_input_row)) {
                // Move to next input row if null
                state.current_input_row++;
                state.initialized_row = false;
                continue;
            }
            
            // Extract repo_path_or_uri from input DataChunk - direct string_t access
            auto data = FlatVector::GetData<string_t>(input.data[0]);
            if (!data) {
                throw BinderException("git_tree_each: no string data in input column");
            }
            
            // Get the string_t directly and convert to string
            auto string_t_value = data[state.current_input_row];
            string repo_path_or_uri(string_t_value.GetData(), string_t_value.GetSize());
            
            if (repo_path_or_uri.empty()) {
                throw BinderException("git_tree_each: received empty repo_path_or_uri from input");
            }
            
            // Get ref parameter - either from input columns or use default (current branch)
            string final_ref = bind_data.ref; // Default from bind
            if (input.ColumnCount() > 1 && !FlatVector::IsNull(input.data[1], state.current_input_row)) {
                auto ref_data = FlatVector::GetData<string_t>(input.data[1]);
                if (ref_data) {
                    auto ref_string_t = ref_data[state.current_input_row];
                    final_ref = string(ref_string_t.GetData(), ref_string_t.GetSize());
                }
            }
            
            // If no ref specified, use current branch (empty string will trigger GitPath to use current branch)
            if (final_ref.empty()) {
                final_ref = "HEAD";  // GitPath::Parse will resolve HEAD to current branch
            }
            
            // Apply unified parameter processing at runtime
            string resolved_file_path;
            
            if (StringUtil::StartsWith(repo_path_or_uri, "git://")) {
                // git:// URI - parse it
                try {
                    auto git_path = GitPath::Parse(repo_path_or_uri);
                    resolved_repo_path = git_path.repository_path;
                    resolved_file_path = git_path.file_path;
                    
                    // Check for ref conflict validation
                    if (!git_path.revision.empty() && final_ref != "HEAD") {
                        throw BinderException("git_tree_each: Conflicting ref specifications: git:// URI contains '@%s' but function parameter specifies '%s'", 
                                            git_path.revision, final_ref);
                    }
                    if (!git_path.revision.empty()) {
                        final_ref = git_path.revision;
                    }
                } catch (const std::exception &e) {
                    throw BinderException("git_tree_each: Failed to parse git:// URI '%s': %s", repo_path_or_uri, e.what());
                }
            } else {
                // Filesystem path - use repository discovery
                try {
                    auto git_path = GitPath::Parse("git://" + repo_path_or_uri + "@" + final_ref);
                    resolved_repo_path = git_path.repository_path;
                    resolved_file_path = git_path.file_path;
                } catch (const std::exception &e) {
                    throw BinderException("git_tree_each: Failed to resolve repository path '%s': %s", repo_path_or_uri, e.what());
                }
            }
            
            // Process the git tree using the resolved parameters
            state.current_rows.clear();
            ProcessTreeCommitForInOut(final_ref, resolved_repo_path, state.current_rows);
            
            state.initialized_row = true;
            state.current_output_row = 0;
        }
        
        if (state.current_output_row >= state.current_rows.size()) {
            // Finished outputting all rows for this input row, move to next
            state.current_input_row++;
            state.initialized_row = false;
            continue;
        }
        
        // Output rows for current input
        idx_t remaining = state.current_rows.size() - state.current_output_row;
        idx_t count = MinValue<idx_t>(remaining, STANDARD_VECTOR_SIZE);
        
        for (idx_t i = 0; i < count; i++) {
            auto &row = state.current_rows[state.current_output_row + i];
            OutputGitTreeRow(output, i, row, resolved_repo_path);
        }
        
        output.SetCardinality(count);
        state.current_output_row += count;
        
        if (state.current_output_row >= state.current_rows.size()) {
            // Finished this input row, setup to move to next
            state.current_input_row++;
            state.initialized_row = false;
        }
        
        return OperatorResultType::HAVE_MORE_OUTPUT;
    }
}

void RegisterGitTreeFunction(DatabaseInstance &db) {
    TableFunctionSet git_tree_set("git_tree");
    
    // Enhanced single commit version
    TableFunction git_tree_single({LogicalType::VARCHAR}, GitTreeFunction, GitTreeBind, GitTreeInitGlobal);
    git_tree_single.named_parameters["repo_path"] = LogicalType::VARCHAR;
    git_tree_set.AddFunction(git_tree_single);
    
    // Two-argument version (repo_path_or_uri, ref)
    TableFunction git_tree_two({LogicalType::VARCHAR, LogicalType::VARCHAR}, GitTreeFunction, GitTreeBind, GitTreeInitGlobal);
    git_tree_two.named_parameters["repo_path"] = LogicalType::VARCHAR;
    git_tree_set.AddFunction(git_tree_two);
    
    // Array version (multiple commits) - WORKING!
    TableFunction git_tree_array({LogicalType::LIST(LogicalType::VARCHAR)}, GitTreeFunction, GitTreeBind, GitTreeInitGlobal);
    git_tree_array.named_parameters["repo_path"] = LogicalType::VARCHAR;
    git_tree_set.AddFunction(git_tree_array);
    
    // Zero-argument version (defaults to HEAD and current directory)
    TableFunction git_tree_zero({}, GitTreeFunction, GitTreeBind, GitTreeInitGlobal);
    git_tree_zero.named_parameters["repo_path"] = LogicalType::VARCHAR;
    git_tree_set.AddFunction(git_tree_zero);
    
    ExtensionUtil::RegisterFunction(db, git_tree_set);
    
    // LATERAL git_tree_each function (commit ref comes from LATERAL context) - ONLY for dynamic input
    TableFunctionSet git_tree_each_set("git_tree_each");
    
    // Version that takes repo_path_or_uri as first parameter (for LATERAL context)
    TableFunction git_tree_each_single({LogicalType::VARCHAR}, nullptr, GitTreeEachBind, nullptr, GitTreeLocalInit);
    git_tree_each_single.in_out_function = GitTreeEachFunction;
    git_tree_each_single.named_parameters["repo_path"] = LogicalType::VARCHAR;
    git_tree_each_set.AddFunction(git_tree_each_single);
    
    // Two-argument version (repo_path_or_uri, ref)
    TableFunction git_tree_each_two({LogicalType::VARCHAR, LogicalType::VARCHAR}, nullptr, GitTreeEachBind, nullptr, GitTreeLocalInit);
    git_tree_each_two.in_out_function = GitTreeEachFunction;
    git_tree_each_two.named_parameters["repo_path"] = LogicalType::VARCHAR;
    git_tree_each_set.AddFunction(git_tree_each_two);
    
    ExtensionUtil::RegisterFunction(db, git_tree_each_set);
}

// Helper function for processing parents of a single commit
static void ProcessParentsForCommit(const string &repo_path, const string &commit_ref, vector<GitParentsRow> &rows) {
    // libgit2 is initialized at extension load time
    
    git_repository *repo = nullptr;
    int error = git_repository_open(&repo, repo_path.c_str());
    if (error != 0) {
        const git_error *e = git_error_last();
        throw IOException("git_parents_each: failed to open repository '%s': %s", 
                        repo_path, e ? e->message : "Unknown error");
    }
    
    // Resolve the commit
    git_object *obj = nullptr;
    if (git_revparse_single(&obj, repo, commit_ref.c_str()) != 0) {
        const git_error *e = git_error_last();
        git_repository_free(repo);
        throw IOException("git_parents_each: cannot resolve ref '%s' in repository '%s': %s", 
                        commit_ref, repo_path, e ? e->message : "Unknown error");
    }
    
    git_commit *commit = nullptr;
    if (git_object_type(obj) != GIT_OBJECT_COMMIT) {
        git_object_free(obj);
        git_repository_free(repo);
        throw IOException("git_parents_each: '%s' does not refer to a commit", commit_ref);
    }
    
    if (git_commit_lookup(&commit, repo, git_object_id(obj)) != 0) {
        git_object_free(obj);
        git_repository_free(repo);
        throw IOException("git_parents_each: failed to lookup commit");
    }
    
    // Get commit hash
    char commit_oid_str[GIT_OID_HEXSZ + 1];
    git_oid_tostr(commit_oid_str, sizeof(commit_oid_str), git_commit_id(commit));
    string commit_hash(commit_oid_str);
    
    // Process parents
    unsigned int parent_count = git_commit_parentcount(commit);
    for (unsigned int i = 0; i < parent_count; i++) {
        const git_oid *parent_oid = git_commit_parent_id(commit, i);
        
        GitParentsRow row;
        row.commit_hash = commit_hash;
        
        char oid_str[GIT_OID_HEXSZ + 1];
        git_oid_tostr(oid_str, sizeof(oid_str), parent_oid);
        row.parent_hash = string(oid_str);
        row.parent_index = i + 1;
        
        rows.push_back(row);
    }
    
    git_commit_free(commit);
    git_object_free(obj);
    git_repository_free(repo);
}

// Bind function for git_parents_each
unique_ptr<FunctionData> GitParentsEachBind(ClientContext &context, TableFunctionBindInput &input,
                                           vector<LogicalType> &return_types, vector<string> &names) {
    auto bind_data = make_uniq<GitParentsEachBindData>();
    
    // Handle optional second parameter (repo_path)
    if (input.inputs.size() >= 2) {
        bind_data->repo_path = StringValue::Get(input.inputs[1]);
    } else {
        bind_data->repo_path = ".";  // Default to current directory
    }
    
    // Resolve repository path
    try {
        auto git_path = GitPath::Parse("git://" + bind_data->repo_path + "@HEAD");
        bind_data->repo_path = git_path.repository_path;
    } catch (const std::exception &e) {
        throw BinderException("git_parents_each: Failed to resolve repository path '%s': %s", 
                            bind_data->repo_path, e.what());
    }
    
    // Define schema
    DefineGitParentsSchema(return_types, names);
    
    return bind_data;
}

// Local init for git_parents_each
unique_ptr<LocalTableFunctionState> GitParentsLocalInit(ExecutionContext &context, TableFunctionInitInput &input, 
                                                       GlobalTableFunctionState *global_state) {
    return make_uniq<GitParentsLocalState>();
}

// LATERAL git_parents_each function
OperatorResultType GitParentsEachFunction(ExecutionContext &context, TableFunctionInput &data_p, 
                                         DataChunk &input, DataChunk &output) {
    auto &bind_data = data_p.bind_data->Cast<GitParentsEachBindData>();
    auto &state = data_p.local_state->Cast<GitParentsLocalState>();
    
    while (true) {
        if (!state.initialized_row) {
            // Initialize for the current input row
            if (state.current_input_row >= input.size()) {
                // Ran out of rows
                state.current_input_row = 0;
                state.initialized_row = false;
                return OperatorResultType::NEED_MORE_INPUT;
            }
            
            // LATERAL function: extract commit_hash from input DataChunk
            input.Flatten();
            
            // Check if input has columns and data
            if (input.ColumnCount() == 0) {
                throw BinderException("git_parents_each: no input columns available");
            }
            
            // Check if the input is null
            if (FlatVector::IsNull(input.data[0], state.current_input_row)) {
                // Move to next input row if null
                state.current_input_row++;
                state.initialized_row = false;
                continue;
            }
            
            // Extract commit_hash from input DataChunk
            auto data = FlatVector::GetData<string_t>(input.data[0]);
            if (!data) {
                throw BinderException("git_parents_each: no string data in input column");
            }
            
            // Get the string_t directly and convert to string
            auto string_t_value = data[state.current_input_row];
            string commit_ref_or_uri(string_t_value.GetData(), string_t_value.GetSize());
            
            if (commit_ref_or_uri.empty()) {
                throw BinderException("git_parents_each: received empty commit reference from input");
            }
            
            // Parse the input - could be a git:// URI or just a commit ref
            string repo_path_to_use = bind_data.repo_path;
            string commit_ref = commit_ref_or_uri;
            
            if (StringUtil::StartsWith(commit_ref_or_uri, "git://")) {
                // git:// URI - parse it to extract repo_path and ref
                try {
                    auto git_path = GitPath::Parse(commit_ref_or_uri);
                    repo_path_to_use = git_path.repository_path;
                    
                    // Use the ref from the URI if present, otherwise default to HEAD
                    if (!git_path.revision.empty()) {
                        commit_ref = git_path.revision;
                    } else {
                        commit_ref = "HEAD";
                    }
                    
                    // Check if there's a repo_path override from the second parameter
                    if (input.ColumnCount() > 1 && !FlatVector::IsNull(input.data[1], state.current_input_row)) {
                        auto repo_data = FlatVector::GetData<string_t>(input.data[1]);
                        if (repo_data) {
                            auto repo_string_t = repo_data[state.current_input_row];
                            string explicit_repo_path(repo_string_t.GetData(), repo_string_t.GetSize());
                            if (!explicit_repo_path.empty()) {
                                // Resolve the explicit repo path
                                try {
                                    auto explicit_git_path = GitPath::Parse("git://" + explicit_repo_path + "@HEAD");
                                    repo_path_to_use = explicit_git_path.repository_path;
                                } catch (const std::exception &e) {
                                    // Keep using the URI-derived repo path
                                }
                            }
                        }
                    }
                } catch (const std::exception &e) {
                    throw BinderException("git_parents_each: Failed to parse git:// URI '%s': %s", commit_ref_or_uri, e.what());
                }
            }
            
            // Process the parents for this commit
            state.current_rows.clear();
            state.current_repo_path = repo_path_to_use;  // Store the resolved repo path
            try {
                ProcessParentsForCommit(repo_path_to_use, commit_ref, state.current_rows);
            } catch (const std::exception &e) {
                // If there's an error processing this commit, skip to the next one
                state.current_input_row++;
                state.initialized_row = false;
                continue;
            }
            
            state.initialized_row = true;
            state.current_output_row = 0;
        }
        
        // Output rows for current input
        idx_t output_count = 0;
        while (output_count < STANDARD_VECTOR_SIZE && 
               state.current_output_row < state.current_rows.size()) {
            
            auto &row = state.current_rows[state.current_output_row];
            
            // Fill output row with parent data
            OutputGitParentsRow(output, output_count, row, state.current_repo_path);
            
            output_count++;
            state.current_output_row++;
        }
        
        // Set output cardinality
        output.SetCardinality(output_count);
        
        // Check if we've output all rows for current input
        if (state.current_output_row >= state.current_rows.size()) {
            // Move to next input row
            state.current_input_row++;
            state.initialized_row = false;
            
            // If we produced some output, return it
            if (output_count > 0) {
                return OperatorResultType::HAVE_MORE_OUTPUT;
            }
            // Otherwise continue with next input
            continue;
        }
        
        // We have more rows to output for current input
        return OperatorResultType::HAVE_MORE_OUTPUT;
    }
}

void RegisterGitParentsFunction(DatabaseInstance &db) {
    // Single-argument version (ref only, for current directory)
    TableFunction git_parents_func_one("git_parents", {LogicalType::VARCHAR}, GitParentsFunction, GitParentsBind, GitParentsInitGlobal);
    git_parents_func_one.named_parameters["all_refs"] = LogicalType::BOOLEAN;
    ExtensionUtil::RegisterFunction(db, git_parents_func_one);
    
    // Two-parameter version (repo_path_or_uri, ref)
    TableFunction git_parents_func_two("git_parents", {LogicalType::VARCHAR, LogicalType::VARCHAR}, GitParentsFunction, GitParentsBind, GitParentsInitGlobal);
    git_parents_func_two.named_parameters["all_refs"] = LogicalType::BOOLEAN;
    ExtensionUtil::RegisterFunction(db, git_parents_func_two);
    
    // Array version (multiple commits) - for consistency with git_tree
    TableFunction git_parents_func_array("git_parents", {LogicalType::LIST(LogicalType::VARCHAR)}, GitParentsFunction, GitParentsBind, GitParentsInitGlobal);
    git_parents_func_array.named_parameters["all_refs"] = LogicalType::BOOLEAN;
    ExtensionUtil::RegisterFunction(db, git_parents_func_array);
    
    // Zero-argument version (defaults to HEAD and current directory)
    TableFunction git_parents_func_zero("git_parents", {}, GitParentsFunction, GitParentsBind, GitParentsInitGlobal);
    git_parents_func_zero.named_parameters["all_refs"] = LogicalType::BOOLEAN;
    ExtensionUtil::RegisterFunction(db, git_parents_func_zero);
    
    // Register git_parents_each variants for LATERAL joins
    TableFunctionSet git_parents_each_set("git_parents_each");
    
    // One-parameter version (commits from LATERAL)
    TableFunction git_parents_each_single({LogicalType::VARCHAR}, nullptr, GitParentsEachBind, nullptr, GitParentsLocalInit);
    git_parents_each_single.in_out_function = GitParentsEachFunction;
    git_parents_each_single.named_parameters["repo_path"] = LogicalType::VARCHAR;
    git_parents_each_set.AddFunction(git_parents_each_single);
    
    // Two-parameter version (commits from LATERAL, repo_path as second parameter)
    TableFunction git_parents_each_two({LogicalType::VARCHAR, LogicalType::VARCHAR}, nullptr, GitParentsEachBind, nullptr, GitParentsLocalInit);
    git_parents_each_two.in_out_function = GitParentsEachFunction;
    git_parents_each_set.AddFunction(git_parents_each_two);
    
    ExtensionUtil::RegisterFunction(db, git_parents_each_set);
}

//===--------------------------------------------------------------------===//
// Git Read Functions (both static and LATERAL support for reading blob content)
//===--------------------------------------------------------------------===//

// Common bind data for both static and LATERAL git_read functions
struct GitReadBindData : public TableFunctionData {
    int64_t max_bytes;
    string decode_base64;
    string transcode;
    string filters;
    string repo_path;
    string uri;  // For static git_read function
    
    GitReadBindData(int64_t max_bytes, const string& decode_base64, const string& transcode, 
                   const string& filters, const string& repo_path, const string& uri = "")
        : max_bytes(max_bytes), decode_base64(decode_base64), transcode(transcode), 
          filters(filters), repo_path(repo_path), uri(uri) {}
};

// Global state for static git_read function
struct GitReadGlobalState : public GlobalTableFunctionState {
    GitReadGlobalState() : finished(false) {}
    bool finished;
};

struct GitReadLocalState : public LocalTableFunctionState {
    GitReadLocalState() = default;
    
    bool initialized_row = false;
    idx_t current_input_row = 0;
    idx_t current_output_row = 0;
    
    git_repository *repo = nullptr;
    
    struct ReadResult {
        string git_uri;           // Renamed from uri - complete git:// URI
        string repo_path;         // NEW - repository filesystem path
        string commit_hash;       // NEW - Git commit hash
        string tree_hash;         // NEW - Git tree hash containing the file
        string file_path;         // NEW - File path within repository
        string file_ext;          // NEW - File extension (e.g., .js, .cpp, .md)
        string ref;              // NEW - Git reference (SHA/branch/tag)
        string blob_hash;         // NEW - Git blob hash of file content
        int32_t mode;            // File mode
        string kind;             // Object kind (blob, tree, etc.)
        bool is_text;            // Whether content is text
        string encoding;         // Text encoding (utf8, binary)
        int64_t size_bytes;      // File size in bytes
        bool truncated;          // Whether content was truncated
        string text;             // Text content
        string blob;             // Base64 encoded binary content
        
        // Constructor to ensure proper initialization
        ReadResult() : 
            git_uri(""), repo_path(""), commit_hash(""), tree_hash(""),
            file_path(""), file_ext(""), ref(""), blob_hash(""),
            mode(0), kind("blob"), is_text(true), encoding("utf8"),
            size_bytes(0), truncated(false), text(""), blob("") {}
    };
    
    vector<ReadResult> current_results;
    
    ~GitReadLocalState() {
        if (repo) {
            git_repository_free(repo);
        }
    }
};

// Init functions
static unique_ptr<GlobalTableFunctionState> GitReadInitGlobal(ClientContext &context, TableFunctionInitInput &input) {
    return make_uniq<GitReadGlobalState>();
}


// Helper function to process a git:// URI and extract content
static void ProcessGitURI(const string& uri, const GitReadBindData& bind_data, 
                         GitReadLocalState::ReadResult& result) {
    // Initialize all fields with defaults
    result.git_uri = uri;
    result.repo_path = "";       // Will be populated from GitPath::Parse
    result.commit_hash = "";     // Will be computed from resolved commit
    result.tree_hash = "";       // Will be computed from tree containing the file  
    result.file_path = "";       // Will be populated from GitPath::Parse
    result.file_ext = "";        // Will be computed from file_path
    result.ref = "";             // Will be populated from GitPath::Parse
    result.blob_hash = "";       // Will be computed from blob OID
    result.mode = 0;
    result.kind = "unknown";
    result.is_text = false;
    result.encoding = "unknown";
    result.size_bytes = 0;
    result.truncated = false;
    result.text = "";
    result.blob = "";
    
    // Use GitPath::Parse for proper repository discovery
    GitPath git_path;
    try {
        git_path = GitPath::Parse(uri);
    } catch (const IOException &e) {
        throw BinderException("git_read: %s", e.what());
    }
    
    // Populate extracted URI components
    result.repo_path = git_path.repository_path;
    result.file_path = git_path.file_path;
    result.ref = git_path.revision;
    result.file_ext = ExtractFileExtension(git_path.file_path);
    
    git_repository *repo = nullptr;
    git_commit *commit = nullptr;
    git_tree *tree = nullptr;
    git_tree_entry *entry = nullptr;
    git_blob *blob = nullptr;
    
    try {
        // Open repository using the discovered repository path
        int error = git_repository_open(&repo, git_path.repository_path.c_str());
        if (error != 0) {
            const git_error *e = git_error_last();
            throw IOException("git_read: failed to open git repository '%s': %s", 
                            git_path.repository_path.c_str(), e ? e->message : "Unknown error");
        }
        
        // Resolve commit (handle both SHA hashes and references like HEAD)
        git_oid commit_oid;
        git_object *obj = nullptr;
        error = git_revparse_single(&obj, repo, git_path.revision.c_str());
        if (error != 0) {
            const git_error *e = git_error_last();
            git_repository_free(repo); repo = nullptr;
            throw IOException("git_read: failed to resolve commit reference '%s': %s", 
                            git_path.revision.c_str(), e ? e->message : "Unknown error");
        }
        
        const git_oid *oid = git_object_id(obj);
        git_oid_cpy(&commit_oid, oid);
        git_object_free(obj);
        
        error = git_commit_lookup(&commit, repo, &commit_oid);
        if (error != 0) {
            const git_error *e = git_error_last();
            git_repository_free(repo); repo = nullptr;
            throw IOException("git_read: commit not found '%s': %s", 
                            git_path.revision.c_str(), e ? e->message : "Unknown error");
        }
        
        // Get tree from commit
        error = git_commit_tree(&tree, commit);
        if (error != 0) {
            const git_error *e = git_error_last();
            git_commit_free(commit); commit = nullptr;
            git_repository_free(repo); repo = nullptr;
            throw IOException("git_read: failed to get commit tree: %s", 
                            e ? e->message : "Unknown error");
        }
        
        // Populate hash fields using existing oid_to_hex function pattern
        result.commit_hash = oid_to_hex(&commit_oid);
        result.tree_hash = oid_to_hex(git_tree_id(tree));
        
        // Find the file in the tree
        error = git_tree_entry_bypath(&entry, tree, git_path.file_path.c_str());
        if (error != 0) {
            git_tree_free(tree); tree = nullptr;
            git_commit_free(commit); commit = nullptr;
            git_repository_free(repo); repo = nullptr;
            throw IOException("git_read: file not found '%s' in commit '%s'", git_path.file_path.c_str(), git_path.revision.c_str());
        }
        
        // Get file mode and kind
        git_filemode_t filemode = git_tree_entry_filemode(entry);
        result.mode = static_cast<int32_t>(filemode);
        
        // Get blob hash from tree entry
        const git_oid *entry_oid = git_tree_entry_id(entry);
        result.blob_hash = oid_to_hex(entry_oid);
        
        switch (filemode) {
            case GIT_FILEMODE_BLOB:
            case GIT_FILEMODE_BLOB_EXECUTABLE:
                result.kind = "file";
                break;
            case GIT_FILEMODE_LINK:
                result.kind = "symlink";
                break;
            case GIT_FILEMODE_TREE:
                result.kind = "tree";
                git_tree_entry_free(entry); entry = nullptr;
                git_tree_free(tree); tree = nullptr;
                git_commit_free(commit); commit = nullptr;
                git_repository_free(repo); repo = nullptr;
                return;
            case GIT_FILEMODE_COMMIT:
                result.kind = "submodule";
                git_tree_entry_free(entry); entry = nullptr;
                git_tree_free(tree); tree = nullptr;
                git_commit_free(commit); commit = nullptr;
                git_repository_free(repo); repo = nullptr;
                return;
            default:
                git_tree_entry_free(entry); entry = nullptr;
                git_tree_free(tree); tree = nullptr;
                git_commit_free(commit); commit = nullptr;
                git_repository_free(repo); repo = nullptr;
                throw IOException("git_read: unsupported file mode %d", static_cast<int>(filemode));
        }
        
        // Get the blob
        const git_oid *blob_oid = git_tree_entry_id(entry);
        error = git_blob_lookup(&blob, repo, blob_oid);
        if (error != 0) {
            const git_error *e = git_error_last();
            git_tree_entry_free(entry); entry = nullptr;
            git_tree_free(tree); tree = nullptr;
            git_commit_free(commit); commit = nullptr;
            git_repository_free(repo); repo = nullptr;
            throw IOException("git_read: failed to load blob: %s", 
                            e ? e->message : "Unknown error");
        }
        
        // Get blob content
        const void *raw_content = git_blob_rawcontent(blob);
        git_off_t raw_size = git_blob_rawsize(blob);
        
        result.size_bytes = static_cast<int64_t>(raw_size);
        
        // Apply max_bytes limit
        size_t content_size = static_cast<size_t>(raw_size);
        if (bind_data.max_bytes > 0 && content_size > static_cast<size_t>(bind_data.max_bytes)) {
            content_size = static_cast<size_t>(bind_data.max_bytes);
            result.truncated = true;
        }
        
        if (content_size > 0) {
            // Use libgit2's efficient binary detection (replaces custom IsTextContent)
            bool is_text = !git_blob_is_binary(blob);  // libgit2 heuristic - checks ~4-8KB
            result.is_text = is_text;
            
            if (is_text) {
                // Create a safe text string with proper memory handling
                const char* char_content = static_cast<const char*>(raw_content);
                
                // Check for null bytes (which can cause verification issues)
                bool has_null_bytes = false;
                for (size_t i = 0; i < content_size; i++) {
                    if (char_content[i] == '\0') {
                        has_null_bytes = true;
                        break;
                    }
                }
                
                // Additional UTF-8 validation
                bool is_valid_utf8 = !has_null_bytes && IsValidUTF8(char_content, content_size);
                
                if (is_valid_utf8) {
                    result.encoding = "utf8";
                    // Create string and ensure it's properly initialized
                    result.text = string(char_content, content_size);
                    
                    // Defensive check: ensure no uninitialized memory patterns
                    if (result.text.find('\xbe') != string::npos) {
                        // Contains suspicious uninitialized memory pattern - treat as binary
                        result.encoding = "binary";
                        result.is_text = false;
                        result.text.clear();
                        result.blob = string(char_content, content_size);
                    }
                } else {
                    // Invalid UTF-8 or contains null bytes - treat as binary
                    result.encoding = "binary";
                    result.is_text = false;
                    result.blob = string(char_content, content_size);
                }
            } else {
                result.encoding = "binary";
                result.blob = string(static_cast<const char*>(raw_content), content_size);
            }
        }
        
        // Clean up
        git_blob_free(blob); blob = nullptr;
        git_tree_entry_free(entry); entry = nullptr;
        git_tree_free(tree); tree = nullptr;
        git_commit_free(commit); commit = nullptr;
        git_repository_free(repo); repo = nullptr;
        
    } catch (...) {
        // Clean up on exception
        if (blob) git_blob_free(blob);
        if (entry) git_tree_entry_free(entry);
        if (tree) git_tree_free(tree);
        if (commit) git_commit_free(commit);
        if (repo) git_repository_free(repo);
        throw; // Re-throw the exception
    }
}

// Bind function for static git_read (single URI parameter)
static unique_ptr<FunctionData> GitReadBind(ClientContext &context, TableFunctionBindInput &input,
                                          vector<LogicalType> &return_types, vector<string> &names) {
    
    // Extract first parameter (repo_path_or_uri_with_file)
    if (input.inputs.empty()) {
        throw BinderException("git_read requires at least one parameter: the file path or git:// URI");
    }
    
    string first_param = input.inputs[0].GetValue<string>();
    string uri;
    string repo_path = ".";
    
    // Check if it's a git:// URI or filesystem path
    if (StringUtil::StartsWith(first_param, "git://")) {
        // git:// URI - use as-is (existing behavior)
        uri = first_param;
    } else {
        // Filesystem path - use unified parameter parsing to build git:// URI
        auto params = ParseUnifiedGitParams(input, 1);  // ref parameter at index 1
        
        // Build git:// URI from discovered repo and file paths
        if (params.resolved_file_path.empty()) {
            throw BinderException("git_read: filesystem path '%s' does not appear to contain a file component", first_param);
        }
        
        uri = "git://" + params.resolved_repo_path + "/" + params.resolved_file_path + "@" + params.ref;
        repo_path = params.resolved_repo_path;
    }
    
    // Set default parameters - note parameter indices shift by 1 if ref was provided
    int64_t max_bytes = -1;  // No limit by default
    string decode_base64 = "auto";
    string transcode = "utf8";  
    string filters = "raw";
    
    // Determine parameter offset based on whether filesystem path had ref parameter
    int param_offset = 1;
    if (!StringUtil::StartsWith(first_param, "git://") && input.inputs.size() >= 2 && 
        input.inputs[1].type().id() == LogicalTypeId::VARCHAR) {
        // Second parameter might be ref for filesystem paths - check if third param is int (max_bytes)
        if (input.inputs.size() >= 3 && input.inputs[2].type().id() == LogicalTypeId::BIGINT) {
            param_offset = 2;  // ref was provided, skip to max_bytes at index 2
        }
    }
    
    // Parse optional parameters with correct offset
    if (input.inputs.size() > param_offset && !input.inputs[param_offset].IsNull()) {
        if (input.inputs[param_offset].type().id() == LogicalTypeId::BIGINT) {
            max_bytes = input.inputs[param_offset].GetValue<int64_t>();
            param_offset++;
        }
    }
    if (input.inputs.size() > param_offset && !input.inputs[param_offset].IsNull()) {
        decode_base64 = input.inputs[param_offset].GetValue<string>();
        param_offset++;
    }
    if (input.inputs.size() > param_offset && !input.inputs[param_offset].IsNull()) {
        transcode = input.inputs[param_offset].GetValue<string>();
        param_offset++;
    }
    if (input.inputs.size() > param_offset && !input.inputs[param_offset].IsNull()) {
        filters = input.inputs[param_offset].GetValue<string>();
    }
    
    // Check for repo_path named parameter (backward compatibility)
    for (const auto &kv : input.named_parameters) {
        if (kv.first == "repo_path") {
            repo_path = kv.second.GetValue<string>();
        }
    }
    
    // Define return schema - matches git_tree first 8 columns + git_read specific columns
    return_types = {
        LogicalType::VARCHAR,  // git_uri (complete git:// URI)
        LogicalType::VARCHAR,  // repo_path (repository filesystem path)
        LogicalType::VARCHAR,  // commit_hash (git commit hash)
        LogicalType::VARCHAR,  // tree_hash (git tree hash containing the file)
        LogicalType::VARCHAR,  // file_path (file path within repository)
        LogicalType::VARCHAR,  // file_ext (file extension)
        LogicalType::VARCHAR,  // ref (git reference)
        LogicalType::VARCHAR,  // blob_hash (git blob hash of file content)
        LogicalType::INTEGER,  // mode (file mode)
        LogicalType::VARCHAR,  // kind (object kind)
        LogicalType::BOOLEAN,  // is_text (whether content is text)
        LogicalType::VARCHAR,  // encoding (text encoding)
        LogicalType::BIGINT,   // size_bytes (file size in bytes)
        LogicalType::BOOLEAN,  // truncated (whether content was truncated)
        LogicalType::VARCHAR,  // text (text content)
        LogicalType::BLOB      // blob (base64 encoded binary content)
    };
    
    names = {"git_uri", "repo_path", "commit_hash", "tree_hash", "file_path", "file_ext", 
             "ref", "blob_hash", "mode", "kind", "is_text", "encoding", "size_bytes", 
             "truncated", "text", "blob"};
    
    return make_uniq<GitReadBindData>(max_bytes, decode_base64, transcode, filters, repo_path, uri);
}

// Static git_read execution function (processes single URI from bind data)
static void GitReadFunction(ClientContext &context, TableFunctionInput &input, DataChunk &output) {
    auto &bind_data = input.bind_data->Cast<GitReadBindData>();
    auto &gstate = input.global_state->Cast<GitReadGlobalState>();
    
    if (gstate.finished) {
        output.SetCardinality(0);
        return;
    }
    
    // Process the URI from bind data
    GitReadLocalState::ReadResult result;
    ProcessGitURI(bind_data.uri, bind_data, result);
    
    // Fill output row using safe SetValue pattern (Our Fix #2)
    output.SetValue(0, 0, Value(result.git_uri));        // git_uri
    output.SetValue(1, 0, Value(result.repo_path));      // repo_path
    output.SetValue(2, 0, Value(result.commit_hash));    // commit_hash
    output.SetValue(3, 0, Value(result.tree_hash));      // tree_hash
    output.SetValue(4, 0, Value(result.file_path));      // file_path
    output.SetValue(5, 0, Value(result.file_ext));       // file_ext
    output.SetValue(6, 0, Value(result.ref));            // ref
    output.SetValue(7, 0, Value(result.blob_hash));      // blob_hash
    output.SetValue(8, 0, Value::INTEGER(result.mode));  // mode
    output.SetValue(9, 0, Value(result.kind));           // kind
    output.SetValue(10, 0, Value::BOOLEAN(result.is_text)); // is_text
    output.SetValue(11, 0, Value(result.encoding));      // encoding
    output.SetValue(12, 0, Value::BIGINT(result.size_bytes)); // size_bytes
    output.SetValue(13, 0, Value::BOOLEAN(result.truncated)); // truncated
    
    // Handle TEXT column
    if (!result.text.empty()) {
        output.SetValue(14, 0, Value(result.text));      // text
    } else {
        FlatVector::SetNull(output.data[14], 0, true);
    }
    
    // BLOB via SetValue (future-proof against non-flat vectors)
    if (!result.blob.empty()) {
        output.SetValue(15, 0, Value::BLOB_RAW(result.blob));
    } else {
        FlatVector::SetNull(output.data[15], 0, true);
    }
    
    output.SetCardinality(1);
    gstate.finished = true;
}

// Bind function for git_read_each (Pure LATERAL function)
static unique_ptr<FunctionData> GitReadEachBind(ClientContext &context, TableFunctionBindInput &input,
                                          vector<LogicalType> &return_types, vector<string> &names) {
    
    // LATERAL-only: reject direct calls, arguments arrive at runtime via input DataChunk
    if (!input.inputs.empty()) {
        throw BinderException("git_read_each is LATERAL-only. For direct calls, use git_read(...) instead");
    }
    const string uri_for_direct_call = "";
    const bool is_direct_call = false;
    
    // Set default parameters
    int64_t max_bytes = -1;  // No limit by default
    string decode_base64 = "auto";
    string transcode = "utf8";
    string filters = "raw";
    string repo_path = ".";
    
    // LATERAL-only: only named parameters are processed at bind time
    // Runtime parameters (repo_path_or_uri, ref, etc.) come via input DataChunk
    for (const auto &kv : input.named_parameters) {
        if (kv.first == "repo_path") {
            repo_path = kv.second.GetValue<string>();
        }
    }
    
    // Define return schema - matches git_tree first 8 columns + git_read specific columns
    return_types = {
        LogicalType::VARCHAR,  // git_uri (complete git:// URI)
        LogicalType::VARCHAR,  // repo_path (repository filesystem path)
        LogicalType::VARCHAR,  // commit_hash (git commit hash)
        LogicalType::VARCHAR,  // tree_hash (git tree hash containing the file)
        LogicalType::VARCHAR,  // file_path (file path within repository)
        LogicalType::VARCHAR,  // file_ext (file extension)
        LogicalType::VARCHAR,  // ref (git reference)
        LogicalType::VARCHAR,  // blob_hash (git blob hash of file content)
        LogicalType::INTEGER,  // mode (file mode)
        LogicalType::VARCHAR,  // kind (object kind)
        LogicalType::BOOLEAN,  // is_text (whether content is text)
        LogicalType::VARCHAR,  // encoding (text encoding)
        LogicalType::BIGINT,   // size_bytes (file size in bytes)
        LogicalType::BOOLEAN,  // truncated (whether content was truncated)
        LogicalType::VARCHAR,  // text (text content)
        LogicalType::BLOB      // blob (base64 encoded binary content)
    };
    
    names = {"git_uri", "repo_path", "commit_hash", "tree_hash", "file_path", "file_ext", 
             "ref", "blob_hash", "mode", "kind", "is_text", "encoding", "size_bytes", 
             "truncated", "text", "blob"};
    
    // LATERAL-only: never store URI in bind_data, it always comes from input DataChunk
    return make_uniq<GitReadBindData>(max_bytes, decode_base64, transcode, filters, repo_path, "");
}

static unique_ptr<LocalTableFunctionState> GitReadLocalInit(ExecutionContext &context, 
                                                           TableFunctionInitInput &input,
                                                           GlobalTableFunctionState *global_state) {
    return make_uniq<GitReadLocalState>();
}

// git_read_each is ONLY for LATERAL joins - processes input from another table
// For direct calls, use git_read instead
static OperatorResultType GitReadEachFunction(ExecutionContext &context, TableFunctionInput &data_p, 
                                        DataChunk &input, DataChunk &output) {
    auto &bind_data = data_p.bind_data->Cast<GitReadBindData>();
    auto &state = data_p.local_state->Cast<GitReadLocalState>();
    
    // LATERAL-only; inputs flow via 'input' data chunk
    
    // Defensive invariants (debug builds) 
    // Note: output.ColumnCount() may differ from schema in LATERAL context
    D_ASSERT(input.ColumnCount() >= 1);
    
    // LATERAL mode - process input chunk
    while (true) {
        if (!state.initialized_row) {
            if (state.current_input_row >= input.size()) {
                state.current_input_row = 0;
                state.initialized_row = false;
                return OperatorResultType::NEED_MORE_INPUT;
            }
            
            // Read inputs via UnifiedVectorFormat (dictionary/constant safe)
            UnifiedVectorFormat repo_fmt;
            input.data[0].ToUnifiedFormat(input.size(), repo_fmt);
            const auto *repo_vals = UnifiedVectorFormat::GetData<string_t>(repo_fmt);
            const auto ridx = repo_fmt.sel->get_index(state.current_input_row);
            if (!repo_fmt.validity.RowIsValid(ridx)) {
                state.current_input_row++;
                state.initialized_row = false;
                continue; // NULL repo/URI row
            }
            const string first_param = repo_vals[ridx].GetString();
            
            string explicit_ref;
            if (input.ColumnCount() > 1) {
                UnifiedVectorFormat ref_fmt;
                input.data[1].ToUnifiedFormat(input.size(), ref_fmt);
                const auto *ref_vals = UnifiedVectorFormat::GetData<string_t>(ref_fmt);
                const auto r2idx = ref_fmt.sel->get_index(state.current_input_row);
                if (ref_fmt.validity.RowIsValid(r2idx)) {
                    explicit_ref = ref_vals[r2idx].GetString();
                }
            }

            // Canonicalize URI
            string uri;
            if (StringUtil::StartsWith(first_param, "git://")) {
                uri = explicit_ref.empty() ? first_param : first_param + "@" + explicit_ref;
            } else {
                const string &ref = explicit_ref.empty() ? string("HEAD") : explicit_ref;
                uri = "git://" + first_param + "@" + ref;
            }
            
            // Process the URI and extract content
            state.current_results.clear();
            GitReadLocalState::ReadResult result;
            ProcessGitURI(uri, bind_data, result);
            state.current_results.push_back(result);
            
            state.initialized_row = true;
            state.current_output_row = 0;
        }
        
        // Output results for current input row (LATERAL mode)
        // Compute how many rows we can output this call
        idx_t remaining = state.current_results.size() - state.current_output_row;
        idx_t count = MinValue<idx_t>(remaining, STANDARD_VECTOR_SIZE);
        
        // Fill columns defensively based on actual column count
        const idx_t col_count = output.ColumnCount();
        
        for (idx_t i = 0; i < count; i++) {
            auto &result = state.current_results[state.current_output_row + i];
            
            // Fill columns up to available count (16-column schema from binder)
            if (col_count > 0)  output.SetValue(0,  i, Value(result.git_uri));        // git_uri
            if (col_count > 1)  output.SetValue(1,  i, Value(result.repo_path));      // repo_path  
            if (col_count > 2)  output.SetValue(2,  i, Value(result.commit_hash));    // commit_hash
            if (col_count > 3)  output.SetValue(3,  i, Value(result.tree_hash));      // tree_hash
            if (col_count > 4)  output.SetValue(4,  i, Value(result.file_path));      // file_path
            if (col_count > 5)  output.SetValue(5,  i, Value(result.file_ext));       // file_ext
            if (col_count > 6)  output.SetValue(6,  i, Value(result.ref));            // ref
            if (col_count > 7)  output.SetValue(7,  i, Value(result.blob_hash));      // blob_hash
            if (col_count > 8)  output.SetValue(8,  i, Value::INTEGER(result.mode));  // mode
            if (col_count > 9)  output.SetValue(9,  i, Value(result.kind));           // kind
            if (col_count > 10) output.SetValue(10, i, Value::BOOLEAN(result.is_text)); // is_text
            if (col_count > 11) output.SetValue(11, i, Value(result.encoding));       // encoding
            if (col_count > 12) output.SetValue(12, i, Value::BIGINT(result.size_bytes)); // size_bytes
            if (col_count > 13) output.SetValue(13, i, Value::BOOLEAN(result.truncated)); // truncated
            
            // Text column (14)
            if (col_count > 14) {
                if (!result.text.empty()) {
                    output.SetValue(14, i, Value(result.text));       // text
                } else {
                    FlatVector::SetNull(output.data[14], i, true);
                }
            }
            
            // BLOB column (15) via SetValue (future-proof against non-flat vectors)
            if (col_count > 15) {
                if (!result.blob.empty()) {
                    output.SetValue(15, i, Value::BLOB_RAW(result.blob));
                } else {
                    FlatVector::SetNull(output.data[15], i, true);
                }
            }
        }
        
        // Set cardinality after all values are filled to ensure proper vector initialization
        output.SetCardinality(count);
        
        state.current_output_row += count;
        
        if (count > 0) {
            if (state.current_output_row >= state.current_results.size()) {
                // Done with this input row - move to next
                state.current_input_row++;
                state.initialized_row = false;
            }
            
            return OperatorResultType::HAVE_MORE_OUTPUT;
        }
        
        // Move to next input row
        state.current_input_row++;
        state.initialized_row = false;
    }
}

void RegisterGitReadFunction(DatabaseInstance &db) {
    // Static git_read function (processes literal URIs)
    // Correct pattern: TableFunction(name, args, function, bind, init_global)
    TableFunctionSet git_read_set("git_read");
    
    TableFunction git_read_1({LogicalType::VARCHAR}, GitReadFunction, GitReadBind, GitReadInitGlobal);
    git_read_1.named_parameters["repo_path"] = LogicalType::VARCHAR;
    git_read_set.AddFunction(git_read_1);
    
    TableFunction git_read_2({LogicalType::VARCHAR, LogicalType::BIGINT}, GitReadFunction, GitReadBind, GitReadInitGlobal);
    git_read_2.named_parameters["repo_path"] = LogicalType::VARCHAR;
    git_read_set.AddFunction(git_read_2);
    
    TableFunction git_read_3({LogicalType::VARCHAR, LogicalType::BIGINT, LogicalType::VARCHAR}, GitReadFunction, GitReadBind, GitReadInitGlobal);
    git_read_3.named_parameters["repo_path"] = LogicalType::VARCHAR;
    git_read_set.AddFunction(git_read_3);
    
    TableFunction git_read_4({LogicalType::VARCHAR, LogicalType::BIGINT, LogicalType::VARCHAR, LogicalType::VARCHAR}, GitReadFunction, GitReadBind, GitReadInitGlobal);
    git_read_4.named_parameters["repo_path"] = LogicalType::VARCHAR;
    git_read_set.AddFunction(git_read_4);
    
    TableFunction git_read_5({LogicalType::VARCHAR, LogicalType::BIGINT, LogicalType::VARCHAR, LogicalType::VARCHAR, LogicalType::VARCHAR}, GitReadFunction, GitReadBind, GitReadInitGlobal);
    git_read_5.named_parameters["repo_path"] = LogicalType::VARCHAR;
    git_read_set.AddFunction(git_read_5);
    
    ExtensionUtil::RegisterFunction(db, git_read_set);
    
    // git_read_each is ONLY for LATERAL joins - first param comes from LATERAL context
    // For direct calls, use git_read instead
    TableFunctionSet git_read_each_set("git_read_each");
    
    // Version 1: repo_path_or_uri_with_file (LATERAL-only)
    TableFunction git_read_each_1({LogicalType::VARCHAR}, nullptr, GitReadEachBind, GitReadInitGlobal, GitReadLocalInit);
    git_read_each_1.in_out_function = GitReadEachFunction;
    git_read_each_1.named_parameters["repo_path"] = LogicalType::VARCHAR;
    git_read_each_set.AddFunction(git_read_each_1);
    
    // Version 2: repo_path_or_uri_with_file, ref (LATERAL-only)
    TableFunction git_read_each_2({LogicalType::VARCHAR, LogicalType::VARCHAR}, nullptr, GitReadEachBind, GitReadInitGlobal, GitReadLocalInit);
    git_read_each_2.in_out_function = GitReadEachFunction;
    git_read_each_2.named_parameters["repo_path"] = LogicalType::VARCHAR;
    git_read_each_set.AddFunction(git_read_each_2);
    
    // Version 3: repo_path_or_uri_with_file, ref, max_bytes (LATERAL-only)
    TableFunction git_read_each_3({LogicalType::VARCHAR, LogicalType::VARCHAR, LogicalType::BIGINT}, nullptr, GitReadEachBind, GitReadInitGlobal, GitReadLocalInit);
    git_read_each_3.in_out_function = GitReadEachFunction;
    git_read_each_3.named_parameters["repo_path"] = LogicalType::VARCHAR;
    git_read_each_set.AddFunction(git_read_each_3);
    
    // Version 4: repo_path_or_uri_with_file, ref, max_bytes, decode_base64 (LATERAL-only)
    TableFunction git_read_each_4({LogicalType::VARCHAR, LogicalType::VARCHAR, LogicalType::BIGINT, LogicalType::VARCHAR}, nullptr, GitReadEachBind, GitReadInitGlobal, GitReadLocalInit);
    git_read_each_4.in_out_function = GitReadEachFunction;
    git_read_each_4.named_parameters["repo_path"] = LogicalType::VARCHAR;
    git_read_each_set.AddFunction(git_read_each_4);
    
    // Version 5: repo_path_or_uri_with_file, ref, max_bytes, decode_base64, transcode (LATERAL-only)
    TableFunction git_read_each_5({LogicalType::VARCHAR, LogicalType::VARCHAR, LogicalType::BIGINT, LogicalType::VARCHAR, LogicalType::VARCHAR}, nullptr, GitReadEachBind, GitReadInitGlobal, GitReadLocalInit);
    git_read_each_5.in_out_function = GitReadEachFunction;
    git_read_each_5.named_parameters["repo_path"] = LogicalType::VARCHAR;
    git_read_each_set.AddFunction(git_read_each_5);
    
    ExtensionUtil::RegisterFunction(db, git_read_each_set);
}

//===--------------------------------------------------------------------===//
// git_uri() Scalar Function - Helper for URI construction
//===--------------------------------------------------------------------===//

static void GitUriFunction(DataChunk &args, ExpressionState &state, Vector &result) {
    // Handle case where all inputs are constant - create constant output
    if (args.data[0].GetVectorType() == VectorType::CONSTANT_VECTOR &&
        args.data[1].GetVectorType() == VectorType::CONSTANT_VECTOR &&
        args.data[2].GetVectorType() == VectorType::CONSTANT_VECTOR) {
        
        auto repo_path_value = ConstantVector::GetData<string_t>(args.data[0]);
        auto file_path_value = ConstantVector::GetData<string_t>(args.data[1]);
        auto commit_ref_value = ConstantVector::GetData<string_t>(args.data[2]);
        
        if (ConstantVector::IsNull(args.data[0]) || 
            ConstantVector::IsNull(args.data[1]) ||
            ConstantVector::IsNull(args.data[2])) {
            ConstantVector::SetNull(result, true);
            return;
        }
        
        string repo_path = repo_path_value->GetString();
        string file_path = file_path_value->GetString();  
        string commit_ref = commit_ref_value->GetString();
        
        // Use common function to construct URI
        string uri = ConstructGitUri(repo_path, file_path, commit_ref);
        
        result.SetVectorType(VectorType::CONSTANT_VECTOR);
        auto result_data = ConstantVector::GetData<string_t>(result);
        *result_data = StringVector::AddString(result, uri);
        return;
    }
    
    // Handle general case with flat vectors
    auto &repo_path_vector = args.data[0];
    auto &file_path_vector = args.data[1]; 
    auto &commit_ref_vector = args.data[2];
    
    UnifiedVectorFormat repo_path_format, file_path_format, commit_ref_format;
    repo_path_vector.ToUnifiedFormat(args.size(), repo_path_format);
    file_path_vector.ToUnifiedFormat(args.size(), file_path_format);
    commit_ref_vector.ToUnifiedFormat(args.size(), commit_ref_format);
    
    auto repo_path_data = UnifiedVectorFormat::GetData<string_t>(repo_path_format);
    auto file_path_data = UnifiedVectorFormat::GetData<string_t>(file_path_format);
    auto commit_ref_data = UnifiedVectorFormat::GetData<string_t>(commit_ref_format);
    
    // Ensure result vector is flat for per-row writes (ChatGPT Fix #1)
    result.SetVectorType(VectorType::FLAT_VECTOR);
    auto result_data = FlatVector::GetData<string_t>(result);
    for (idx_t i = 0; i < args.size(); i++) {
        auto repo_idx = repo_path_format.sel->get_index(i);
        auto file_idx = file_path_format.sel->get_index(i);
        auto commit_idx = commit_ref_format.sel->get_index(i);
        
        if (!repo_path_format.validity.RowIsValid(repo_idx) || 
            !file_path_format.validity.RowIsValid(file_idx) ||
            !commit_ref_format.validity.RowIsValid(commit_idx)) {
            FlatVector::SetNull(result, i, true);
            continue;
        }
        
        string repo_path = repo_path_data[repo_idx].GetString();
        string file_path = file_path_data[file_idx].GetString();  
        string commit_ref = commit_ref_data[commit_idx].GetString();
        
        // Use common function to construct URI
        string uri = ConstructGitUri(repo_path, file_path, commit_ref);
        
        result_data[i] = StringVector::AddString(result, uri);
    }
}

static void RegisterGitUriFunction(DatabaseInstance &db) {
    auto git_uri_func = ScalarFunction("git_uri",
        {LogicalType::VARCHAR, LogicalType::VARCHAR, LogicalType::VARCHAR},
        LogicalType::VARCHAR,
        GitUriFunction);
    ExtensionUtil::RegisterFunction(db, git_uri_func);
}

void RegisterGitCloneFunction(DatabaseInstance &db) {
    // git_clone functionality temporarily disabled due to StringVector API issues
    // See git-clone.md for details on the API mismatch problem
    // TODO: Fix StringVector::AddString calls in git_clone.cpp and re-enable
    
    /*
    // git_clone(url) -> TABLE
    TableFunction git_clone_1("git_clone", {LogicalType::VARCHAR}, GitCloneFunction, GitCloneBind, GitCloneInitGlobal);
    git_clone_1.named_parameters["repo_path"] = LogicalType::VARCHAR;
    ExtensionUtil::RegisterFunction(db, git_clone_1);
    
    // git_clone(url, local_path) -> TABLE  
    TableFunction git_clone_2("git_clone", {LogicalType::VARCHAR, LogicalType::VARCHAR}, GitCloneFunction, GitCloneBind, GitCloneInitGlobal);
    git_clone_2.named_parameters["repo_path"] = LogicalType::VARCHAR;
    ExtensionUtil::RegisterFunction(db, git_clone_2);
    
    // git_clone(url, options) -> TABLE
    TableFunction git_clone_3("git_clone", {LogicalType::VARCHAR, LogicalType::STRUCT({})}, GitCloneFunction, GitCloneBind, GitCloneInitGlobal);
    git_clone_3.named_parameters["repo_path"] = LogicalType::VARCHAR;
    ExtensionUtil::RegisterFunction(db, git_clone_3);
    
    // git_clone(url, local_path, options) -> TABLE
    TableFunction git_clone_4("git_clone", {LogicalType::VARCHAR, LogicalType::VARCHAR, LogicalType::STRUCT({})}, GitCloneFunction, GitCloneBind, GitCloneInitGlobal);
    git_clone_4.named_parameters["repo_path"] = LogicalType::VARCHAR;
    ExtensionUtil::RegisterFunction(db, git_clone_4);
    
    // LATERAL git_clone_each functions (URL comes from LATERAL context)
    TableFunctionSet git_clone_each_set("git_clone_each");
    
    // Version that takes URL as first parameter (for LATERAL context)
    TableFunction git_clone_each_single({LogicalType::VARCHAR}, nullptr, GitCloneEachBind, nullptr, GitCloneLocalInit);
    git_clone_each_single.in_out_function = GitCloneEachFunction;
    git_clone_each_single.named_parameters["repo_path"] = LogicalType::VARCHAR;
    git_clone_each_set.AddFunction(git_clone_each_single);
    
    // Two-argument version (url, local_path)
    TableFunction git_clone_each_two({LogicalType::VARCHAR, LogicalType::VARCHAR}, nullptr, GitCloneEachBind, nullptr, GitCloneLocalInit);
    git_clone_each_two.in_out_function = GitCloneEachFunction;
    git_clone_each_two.named_parameters["repo_path"] = LogicalType::VARCHAR;
    git_clone_each_set.AddFunction(git_clone_each_two);
    
    // With options struct (url, options)
    TableFunction git_clone_each_opts({LogicalType::VARCHAR, LogicalType::STRUCT({})}, nullptr, GitCloneEachBind, nullptr, GitCloneLocalInit);
    git_clone_each_opts.in_out_function = GitCloneEachFunction;
    git_clone_each_opts.named_parameters["repo_path"] = LogicalType::VARCHAR;
    git_clone_each_set.AddFunction(git_clone_each_opts);
    
    // Full version (url, local_path, options)
    TableFunction git_clone_each_full({LogicalType::VARCHAR, LogicalType::VARCHAR, LogicalType::STRUCT({})}, nullptr, GitCloneEachBind, nullptr, GitCloneLocalInit);
    git_clone_each_full.in_out_function = GitCloneEachFunction;
    git_clone_each_full.named_parameters["repo_path"] = LogicalType::VARCHAR;
    git_clone_each_set.AddFunction(git_clone_each_full);
    
    ExtensionUtil::RegisterFunction(db, git_clone_each_set);
    */
}

void RegisterGitFunctions(DatabaseInstance &db) {
    RegisterGitLogFunction(db);
    RegisterGitBranchesFunction(db);
    RegisterGitTagsFunction(db);
    RegisterGitTreeFunction(db);
    RegisterGitParentsFunction(db);
    RegisterGitReadFunction(db);
    RegisterGitUriFunction(db);
    // RegisterGitCloneFunction(db); // Temporarily disabled due to StringVector API issues
}

} // namespace duckdb